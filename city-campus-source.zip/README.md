# Rose Morning · City Campus

A pastel first-person campus for a group English class. Walk from the lobby into an English classroom, an AI study lounge, two offices for rent, a room for sketching your own AI office, a quiet garden, and a river terrace.

The buildings, signs, and furniture are simple 3D shapes made for this page. The mood borrows from the [Rose Morning Group Class](https://rose-morning-group-class.lonecreek32.chatgpt.site/) city campus — bright mornings, shared rooms, a place to pause by the water — and from the calm of a slow temple-garden walk. It is not a copy of either place.

## Run it

The page is static. It needs a small local server so the modules can load. Opening the HTML file directly will not work.

```bash
python3 -m http.server 8743
```

Then open [http://127.0.0.1:8743/](http://127.0.0.1:8743/).

Three.js is included in `vendor/three`. Fraunces, Nunito, and Noto Sans KR are included under the SIL Open Font License (`fonts/OFL.txt`). The page does not call any paid service.

Add `?shot=lobby` or `?shot=classroom` to open on a fixed view. Other frames: `lounge`, `garden`, `office`, `terrace`.

## Controls

**Desktop.** Click the scene, then look with the mouse. You can also drag when the pointer is free. WASD or the arrow keys walk. Hold Shift to hurry. Esc releases the mouse. F or E picks up a snack.

**Phone and tablet.** The joystick on the left walks. Drag anywhere else to look.

**VR.** On a Quest browser, use Enter VR. The left stick walks and the right stick turns. The same campus works in an ordinary browser with no headset.

Step up to a sign and the note also appears on screen, in English with Korean underneath. **Homepage** in the corner opens [rose-morning-8c171.web.app](https://rose-morning-8c171.web.app/). **Game campus** opens the earlier walkable campus at [rose-morning-group-class](https://rose-morning-group-class.lonecreek32.chatgpt.site/).

## What's inside

- **Lobby / 로비.** The Rose Morning sign, a campus map, and a morning pantry.
- **English classroom / 영어 교실.** A whiteboard and nine desks for group English.
- **AI study lounge / AI 공부 라운지.** A shared screen and prompt cards. No account required.
- **Club rooms / 4-5인 동아리실.** Two rental rooms, each with one table and five seats.
- **Sea project deck / 바다 작업 데크.** Large tables for group work, open toward the water.
- **Build your AI office / AI 사무실 만들기.** A large work table, a screen, and a kit of parts.
- **Quiet garden / 고요한 정원.** A pond, a wooden deck, a moon gate, lanterns, and cushions.
- **Sea terrace / 바다 테라스.** Sand, open water, and a city on the horizon.

Near a snack, notebook, marker, or kit piece, press F or E, or Pick up. In the English classroom, stand at the whiteboard and write a short line. It shows on the right side of the board. Meet in the corner opens Google Meet. Inside a club room or the AI office, the whiteboard is the same link: click the board and the meeting opens. Paste a code and it stays written on that board.
