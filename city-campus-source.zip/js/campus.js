import * as THREE from "three";
import {
  aiWallTexture,
  gridTexture,
  headerTexture,
  heroTexture,
  mapTexture,
  medallionTexture,
  plankTexture,
  posterTexture,
  promptTexture,
  whiteboardTexture,
} from "./paint.js?v=20";

const T = 0.36;
const WALL_H = 4.8;
const FLOOR = 0.035;

export function createCampus(anisotropy) {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0xf7f8fa);
  scene.fog = new THREE.Fog(0xf7f8fa, 78, 180);

  const aabbs = [];
  const circles = [];
  const signs = [];
  const snacks = [];
  const ripples = [];
  const clouds = [];
  let signId = 0;

  const std = (color, roughness = 0.88, extra = {}) =>
    new THREE.MeshStandardMaterial({ color, roughness, metalness: 0.02, ...extra });

  function plasterMap(maxAniso) {
    const c = document.createElement("canvas");
    c.width = 256;
    c.height = 256;
    const g = c.getContext("2d");
    const pixels = g.createImageData(256, 256);
    for (let i = 0; i < pixels.data.length; i += 4) {
      const n = 238 + Math.random() * 12;
      pixels.data[i] = n;
      pixels.data[i + 1] = n;
      pixels.data[i + 2] = n - 2;
      pixels.data[i + 3] = 255;
    }
    g.putImageData(pixels, 0, 0);
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(2.5, 2);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = maxAniso;
    return tex;
  }

  const mats = {
    wall: std(0xf4f1eb, 0.92, { map: plasterMap(anisotropy) }),
    ceil: std(0xf7f6f3, 0.97),
    trim: std(0xd5cdc3, 0.84),
    wood: std(0xc9956a, 0.74),
    woodDeep: std(0xa8823c, 0.68),
    desk: std(0xfffcf6, 0.76),
    hedge: std(0x7f9a72, 1),
    grass: std(0xc5d3a4, 0.96),
    stone: std(0xfaf4f6, 0.94),
    pad: std(0xe6e1d8, 0.94),
    lobby: std(0xf6f3ee, 0.92),
    classFloor: std(0xfbf6f7, 0.92),
    lounge: std(0xfaf4f6, 0.92),
    roof: std(0xe7e2da, 0.96),
    pot: std(0xb5643c, 0.8),
    trunk: std(0xc6a586, 0.88),
    leaf: std(0x7fb07a, 0.92),
    leafDeep: std(0x68986e, 0.94),
    blossom: std(0xf3c3ce, 0.86),
    petal: std(0xf8e0e6, 0.8),
    lily: std(0x6eaa78, 0.82),
    rose: std(0xe7b7c6, 0.8),
    dusty: std(0xc98a96, 0.74),
    wine: std(0x6e1f2a, 0.7),
    gold: std(0xc9a96e, 0.58),
    sage: std(0xc5d3b4, 0.84),
    butter: std(0xf3e2a8, 0.76),
    sky: std(0xd7e3e4, 0.78),
    lilac: std(0xead8d2, 0.82),
    city: [std(0xf0d0c4), std(0xe7d3a8), std(0xd8b48a), std(0xc98b7a)],
    glass: new THREE.MeshStandardMaterial({
      color: 0xf4fbff,
      transparent: true,
      opacity: 0.14,
      roughness: 0.04,
      metalness: 0.02,
      depthWrite: false,
      side: THREE.DoubleSide,
    }),
    lamp: new THREE.MeshStandardMaterial({
      color: 0xffc27a,
      emissive: 0xff4d00,
      emissiveIntensity: 1.6,
      roughness: 0.32,
    }),
    bulb: new THREE.MeshBasicMaterial({ color: 0xfff3d4 }),
    plank: std(0xffffff, 0.8, { map: plankTexture(anisotropy) }),
    grid: std(0xffffff, 0.86, { map: gridTexture(anisotropy) }),
  };
  const cloths = [mats.rose, mats.sky, mats.butter, mats.sage, mats.lilac];

  function solid(w, h, d, x, y, z, mat, collide = false, cast = true) {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    mesh.position.set(x, y, z);
    mesh.castShadow = cast;
    mesh.receiveShadow = true;
    scene.add(mesh);
    if (collide) {
      aabbs.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2 });
    }
    return mesh;
  }

  function wallX(x, z0, z1, h = WALL_H) {
    const zMin = Math.min(z0, z1);
    const zMax = Math.max(z0, z1);
    if (zMax - zMin < 0.04) return;
    solid(T, h, zMax - zMin, x, h / 2, (zMin + zMax) / 2, mats.wall, true);
  }

  function wallZ(z, x0, x1, h = WALL_H) {
    const xMin = Math.min(x0, x1);
    const xMax = Math.max(x0, x1);
    if (xMax - xMin < 0.04) return;
    solid(xMax - xMin, h, T, (xMin + xMax) / 2, h / 2, z, mats.wall, true);
  }

  function openingHole(span, hole, alongX) {
    const sill = hole.y - hole.h / 2;
    const top = hole.y + hole.h / 2;
    if (sill > 0.05) {
      if (alongX) solid(span, sill, T, hole.x, sill / 2, hole.z, mats.wall, true);
      else solid(T, sill, span, hole.x, sill / 2, hole.z, mats.wall, true);
    }
    const head = WALL_H - top;
    if (head > 0.05) {
      if (alongX) solid(span, head, T, hole.x, top + head / 2, hole.z, mats.wall, true);
      else solid(T, head, span, hole.x, top + head / 2, hole.z, mats.wall, true);
    }
  }

  function wallZGaps(z, x0, x1, holes) {
    const xMin = Math.min(x0, x1);
    const xMax = Math.max(x0, x1);
    const sorted = holes
      .filter((hole) => hole.z === z && hole.x + hole.w / 2 > xMin && hole.x - hole.w / 2 < xMax)
      .sort((a, b) => a.x - b.x);
    let cursor = xMin;
    sorted.forEach((hole) => {
      const left = Math.max(xMin, hole.x - hole.w / 2);
      const right = Math.min(xMax, hole.x + hole.w / 2);
      if (left > cursor + 0.04) wallZ(z, cursor, left);
      openingHole(right - left, { ...hole, z }, true);
      cursor = right;
    });
    if (xMax > cursor + 0.04) wallZ(z, cursor, xMax);
  }

  function wallXGaps(x, z0, z1, holes) {
    const zMin = Math.min(z0, z1);
    const zMax = Math.max(z0, z1);
    const sorted = holes
      .filter((hole) => hole.x === x && hole.z + hole.w / 2 > zMin && hole.z - hole.w / 2 < zMax)
      .sort((a, b) => a.z - b.z);
    let cursor = zMin;
    sorted.forEach((hole) => {
      const near = Math.max(zMin, hole.z - hole.w / 2);
      const far = Math.min(zMax, hole.z + hole.w / 2);
      if (near > cursor + 0.04) wallX(x, cursor, near);
      openingHole(far - near, hole, false);
      cursor = far;
    });
    if (zMax > cursor + 0.04) wallX(x, cursor, zMax);
  }

  function floor(x, z, w, d, mat, y = 0.036) {
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, d), mat);
    mesh.rotation.x = -Math.PI / 2;
    mesh.position.set(x, y, z);
    mesh.receiveShadow = true;
    scene.add(mesh);
    return mesh;
  }

  function disc(x, z, r, mat, y, segments = 40) {
    const mesh = new THREE.Mesh(new THREE.CircleGeometry(r, segments), mat);
    mesh.rotation.x = -Math.PI / 2;
    mesh.position.set(x, y, z);
    mesh.receiveShadow = true;
    scene.add(mesh);
    return mesh;
  }

  function part(parent, w, h, d, x, y, z, mat) {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    parent.add(mesh);
    return mesh;
  }

  function localToWorld(x, z, yaw, lx, lz) {
    const c = Math.cos(yaw);
    const s = Math.sin(yaw);
    return [x + lx * c + lz * s, z - lx * s + lz * c];
  }

  function addAABB(x, z, w, d, yaw = 0) {
    const c = Math.abs(Math.cos(yaw));
    const s = Math.abs(Math.sin(yaw));
    const worldW = w * c + d * s;
    const worldD = w * s + d * c;
    aabbs.push({
      minX: x - worldW / 2,
      maxX: x + worldW / 2,
      minZ: z - worldD / 2,
      maxZ: z + worldD / 2,
    });
  }

  function paper(tex) {
    return new THREE.MeshStandardMaterial({
      map: tex,
      roughness: 0.9,
      metalness: 0,
      emissive: new THREE.Color(0xfff8f3),
      emissiveMap: tex,
      emissiveIntensity: 0.22,
    });
  }

  function register(x, z, radius, info) {
    signId += 1;
    signs.push({ id: `sign-${signId}`, x, z, r: radius, ...info });
  }

  function panel(x, y, z, yaw, w, h, mat, frameMat = mats.trim) {
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.y = yaw;
    const frame = new THREE.Mesh(new THREE.BoxGeometry(w + 0.08, h + 0.08, 0.05), frameMat);
    frame.position.z = -0.02;
    frame.castShadow = true;
    const face = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
    face.position.z = 0.025;
    group.add(frame, face);
    scene.add(group);
    return group;
  }

  function standing(x, z, yaw, w, h, mat, info, frameMat = mats.trim) {
    const y = 1.2;
    const group = new THREE.Group();
    group.position.set(x, 0, z);
    group.rotation.y = yaw;
    const frame = new THREE.Mesh(new THREE.BoxGeometry(w + 0.08, h + 0.08, 0.07), frameMat);
    frame.position.y = y;
    frame.castShadow = true;
    const front = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
    front.position.set(0, y, 0.04);
    const back = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
    back.position.set(0, y, -0.04);
    back.rotation.y = Math.PI;
    const post = new THREE.Mesh(new THREE.BoxGeometry(0.08, y - h / 2, 0.08), mats.wood);
    post.position.set(-w / 2 + 0.06, (y - h / 2) / 2, 0);
    post.castShadow = true;
    const postR = post.clone();
    postR.position.x *= -1;
    group.add(frame, front, back, post, postR);
    scene.add(group);
    circles.push({ x, z, r: 0.32 });
    if (info) register(x, z, info.r || 2.25, info);
  }

  const meetPaints = {};
  function drawMeetBoard(g, code) {
    g.fillStyle = "#f4f8f7";
    g.fillRect(0, 0, 1280, 720);
    g.strokeStyle = "#e4ddd2";
    g.lineWidth = 2;
    for (let y = 86; y < 700; y += 64) {
      g.beginPath();
      g.moveTo(48, y);
      g.lineTo(1232, y);
      g.stroke();
    }
    g.fillStyle = "#1a73e8";
    g.beginPath();
    g.arc(640, 168, 26, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = "#2e2420";
    g.textAlign = "center";
    g.textBaseline = "middle";
    g.font = "700 78px Nunito, sans-serif";
    g.fillText("Google Meet", 640, 250);
    g.fillStyle = "#1a4f78";
    g.font = "700 52px Nunito, sans-serif";
    g.fillText(code || "meet.google.com/new", 640, 360);
    g.fillStyle = "#6e1f2a";
    g.font = "600 36px 'Noto Sans KR', sans-serif";
    g.fillText("이 칠판을 누르면 회의가 열립니다", 640, 470);
    g.fillStyle = "#7a6a5e";
    g.font = "600 28px Nunito, sans-serif";
    g.fillText("Click this board", 640, 530);
  }
  function meetBoard(x, y, z, yaw, id, w = 2.35, h = 1.32) {
    const c = document.createElement("canvas");
    c.width = 1280;
    c.height = 720;
    const g = c.getContext("2d");
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = anisotropy;
    const mat = new THREE.MeshStandardMaterial({
      map: tex,
      roughness: 0.84,
      emissive: new THREE.Color(0xfffaf6),
      emissiveMap: tex,
      emissiveIntensity: 0.2,
    });
    const paint = (code) => {
      drawMeetBoard(g, code || "");
      tex.needsUpdate = true;
    };
    paint("");
    meetPaints[id] = paint;
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.y = yaw;
    group.userData.meet = id;
    const frame = new THREE.Mesh(new THREE.BoxGeometry(w + 0.12, h + 0.12, 0.06), mats.wood);
    frame.castShadow = true;
    const face = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
    face.position.z = 0.04;
    face.userData.meet = id;
    const tray = new THREE.Mesh(new THREE.BoxGeometry(w * 0.46, 0.045, 0.1), mats.gold);
    tray.position.set(0, -h / 2 - 0.01, 0.07);
    group.add(frame, face, tray);
    scene.add(group);
  }
  const artLoader = new THREE.TextureLoader();
  function hangArt(x, y, z, yaw, h, file, aspect, title) {
    const w = h * aspect;
    const tex = artLoader.load(`art/${file}`);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = anisotropy;
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.y = yaw;
    const frame = new THREE.Mesh(new THREE.BoxGeometry(w + 0.14, h + 0.14, 0.07), mats.gold);
    frame.castShadow = true;
    const matte = new THREE.Mesh(new THREE.BoxGeometry(w + 0.06, h + 0.06, 0.02), std(0xfffbfb, 0.72));
    matte.position.z = 0.03;
    const face = new THREE.Mesh(
      new THREE.PlaneGeometry(w, h),
      new THREE.MeshStandardMaterial({ map: tex, roughness: 0.45, metalness: 0 }),
    );
    face.position.z = 0.048;
    const plateCanvas = document.createElement("canvas");
    plateCanvas.width = 640;
    plateCanvas.height = 96;
    const plateG = plateCanvas.getContext("2d");
    plateG.fillStyle = "#f7f3ee";
    plateG.fillRect(0, 0, 640, 96);
    plateG.fillStyle = "#3a2e28";
    plateG.font = "600 34px Nunito, serif";
    plateG.textAlign = "center";
    plateG.textBaseline = "middle";
    plateG.fillText(title, 320, 48);
    const plateTex = new THREE.CanvasTexture(plateCanvas);
    plateTex.colorSpace = THREE.SRGBColorSpace;
    const plate = new THREE.Mesh(
      new THREE.PlaneGeometry(Math.min(w, 1.15), 0.16),
      new THREE.MeshStandardMaterial({ map: plateTex, roughness: 0.8 }),
    );
    plate.position.set(0, -h / 2 - 0.16, 0.04);
    group.add(frame, matte, face, plate);
    scene.add(group);
  }

  function plaque(x, y, z, yaw, w, h, mat) {
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.y = yaw;
    const frame = new THREE.Mesh(new THREE.BoxGeometry(w + 0.07, h + 0.08, 0.045), mats.gold);
    frame.castShadow = true;
    const face = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
    face.position.z = 0.03;
    const cap = new THREE.Mesh(new THREE.BoxGeometry(w + 0.16, 0.055, 0.07), mats.wine);
    cap.position.set(0, h / 2 + 0.05, 0.01);
    group.add(frame, face, cap);
    scene.add(group);
  }

  function windowAt(x, y, z, yaw, w, h) {
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.y = yaw;
    const bar = 0.07;
    const depth = 0.08;
    const top = new THREE.Mesh(new THREE.BoxGeometry(w + bar * 2, bar, depth), mats.trim);
    top.position.y = h / 2 + bar / 2;
    const bottom = top.clone();
    bottom.position.y *= -1;
    const left = new THREE.Mesh(new THREE.BoxGeometry(bar, h, depth), mats.trim);
    left.position.x = -w / 2 - bar / 2;
    const right = left.clone();
    right.position.x *= -1;
    const glass = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mats.glass);
    const mullionV = new THREE.Mesh(new THREE.BoxGeometry(0.04, h, 0.03), mats.trim);
    const mullionH = new THREE.Mesh(new THREE.BoxGeometry(w, 0.04, 0.03), mats.trim);
    group.add(top, bottom, left, right, glass, mullionV, mullionH);
    scene.add(group);
  }

  function plant(x, z, s = 1, blossom = false) {
    const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.16 * s, 0.12 * s, 0.22 * s, 14), mats.pot);
    pot.position.set(x, FLOOR + 0.11 * s, z);
    pot.castShadow = true;
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.04 * s, 0.055 * s, 0.4 * s, 8), mats.trunk);
    trunk.position.set(x, FLOOR + 0.38 * s, z);
    trunk.castShadow = true;
    const crown = new THREE.Mesh(new THREE.SphereGeometry(0.26 * s, 14, 12), blossom ? mats.blossom : mats.leaf);
    crown.position.set(x, FLOOR + 0.68 * s, z);
    crown.castShadow = true;
    const puff = new THREE.Mesh(
      new THREE.SphereGeometry(0.16 * s, 12, 10),
      blossom ? mats.petal : mats.leafDeep,
    );
    puff.position.set(x + 0.12 * s, FLOOR + 0.84 * s, z + 0.04 * s);
    puff.castShadow = true;
    scene.add(pot, trunk, crown, puff);
    if (s >= 1.25) {
      const side = new THREE.Mesh(
        new THREE.SphereGeometry(0.2 * s, 12, 10),
        blossom ? mats.petal : mats.leaf,
      );
      side.position.set(x - 0.18 * s, FLOOR + 0.58 * s, z - 0.08 * s);
      side.castShadow = true;
      scene.add(side);
    }
    circles.push({ x, z, r: 0.18 * s + 0.05 });
  }

  function tree(x, z, s, blossom = false) {
    const trunkH = 1.28 * s;
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.07 * s, 0.11 * s, trunkH, 8), mats.trunk);
    trunk.position.set(x, trunkH / 2, z);
    trunk.castShadow = true;
    const radius = 0.48 * s;
    const crown = new THREE.Mesh(new THREE.SphereGeometry(radius, 16, 12), blossom ? mats.blossom : mats.leaf);
    crown.position.set(x, trunkH + radius * 0.45, z);
    crown.castShadow = true;
    const puff = new THREE.Mesh(
      new THREE.SphereGeometry(radius * 0.7, 14, 10),
      blossom ? mats.petal : mats.leafDeep,
    );
    puff.position.set(x + radius * 0.4, trunkH + radius * 0.75, z + 0.1);
    puff.castShadow = true;
    scene.add(trunk, crown, puff);
    circles.push({ x, z, r: 0.18 * s + 0.1 });
  }

  function lantern(x, z) {
    solid(0.34, 0.1, 0.34, x, 0.05, z, mats.stone, false, true);
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.06, 0.72, 8), mats.wood);
    post.position.set(x, 0.46, z);
    post.castShadow = true;
    scene.add(post);
    solid(0.28, 0.32, 0.28, x, 0.96, z, mats.woodDeep, false, true);
    const glow = new THREE.Mesh(new THREE.PlaneGeometry(0.14, 0.16), mats.bulb);
    glow.position.set(x, 0.96, z + 0.145);
    const glowB = glow.clone();
    glowB.position.z = z - 0.145;
    glowB.rotation.y = Math.PI;
    scene.add(glow, glowB);
    const roof = new THREE.Mesh(new THREE.ConeGeometry(0.24, 0.2, 4), mats.rose);
    roof.position.set(x, 1.22, z);
    roof.rotation.y = Math.PI / 4;
    roof.castShadow = true;
    scene.add(roof);
    circles.push({ x, z, r: 0.24 });
  }

  function column(x, z) {
    const mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.24, WALL_H, 18), mats.wall);
    mesh.position.set(x, WALL_H / 2, z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    scene.add(mesh);
    circles.push({ x, z, r: 0.26 });
  }

  function chair(x, z, yaw, mat) {
    const group = new THREE.Group();
    group.position.set(x, 0, z);
    group.rotation.y = yaw;
    part(group, 0.46, 0.08, 0.42, 0, FLOOR + 0.46, 0, mat);
    part(group, 0.46, 0.4, 0.07, 0, FLOOR + 0.7, -0.2, mat);
    part(group, 0.38, 0.08, 0.36, 0, FLOOR + 0.2, 0, mats.wood);
    scene.add(group);
    addAABB(x, z, 0.48, 0.5, yaw);
  }

  function sofa(x, z, yaw, length, mat) {
    const group = new THREE.Group();
    group.position.set(x, 0, z);
    group.rotation.y = yaw;
    part(group, length, 0.16, 0.64, 0, FLOOR + 0.32, 0, mat);
    part(group, length, 0.42, 0.14, 0, FLOOR + 0.58, -0.28, mat);
    part(group, 0.12, 0.32, 0.58, -length / 2 + 0.06, FLOOR + 0.4, 0.02, mat);
    part(group, 0.12, 0.32, 0.58, length / 2 - 0.06, FLOOR + 0.4, 0.02, mat);
    part(group, 0.26, 0.16, 0.1, -length * 0.22, FLOOR + 0.62, -0.2, mats.butter);
    [
      [-length / 2 + 0.14, -0.22],
      [length / 2 - 0.14, -0.22],
      [-length / 2 + 0.14, 0.2],
      [length / 2 - 0.14, 0.2],
    ].forEach(([lx, lz]) => {
      part(group, 0.05, 0.16, 0.05, lx, FLOOR + 0.08, lz, mats.woodDeep);
    });
    scene.add(group);
    addAABB(x, z, length + 0.08, 0.78, yaw);
  }

  function studentDesk(x, z, yaw, index, sofaSeat = false) {
    const group = new THREE.Group();
    group.position.set(x, 0, z);
    group.rotation.y = yaw;
    const cloth = cloths[index % cloths.length];
    part(group, 1.62, 0.08, 0.92, 0, FLOOR + 0.76, 0, mats.desk);
    part(group, 0.14, 0.72, 0.14, 0, FLOOR + 0.36, 0, mats.woodDeep);
    if (sofaSeat) {
      part(group, 1.22, 0.16, 0.58, 0, FLOOR + 0.34, -0.88, cloth);
      part(group, 1.22, 0.38, 0.12, 0, FLOOR + 0.56, -1.14, cloth);
      part(group, 0.12, 0.28, 0.52, -0.62, FLOOR + 0.4, -0.9, cloth);
      part(group, 0.12, 0.28, 0.52, 0.62, FLOOR + 0.4, -0.9, cloth);
      part(group, 0.24, 0.14, 0.1, -0.32, FLOOR + 0.58, -1.04, mats.butter);
      [
        [-0.5, -1.06],
        [0.5, -1.06],
        [-0.5, -0.7],
        [0.5, -0.7],
      ].forEach(([lx, lz]) => {
        part(group, 0.05, 0.16, 0.05, lx, FLOOR + 0.08, lz, mats.woodDeep);
      });
    } else {
      part(group, 0.52, 0.09, 0.48, 0, FLOOR + 0.48, -0.78, cloth);
      part(group, 0.52, 0.46, 0.08, 0, FLOOR + 0.74, -1.0, cloth);
      part(group, 0.46, 0.08, 0.42, 0, FLOOR + 0.22, -0.78, mats.wood);
    }
    part(group, 0.34, 0.03, 0.24, 0.32, FLOOR + 0.82, 0.06, cloth);
    scene.add(group);
    const [cx, cz] = localToWorld(x, z, yaw, 0, -0.28);
    addAABB(cx, cz, 1.62, sofaSeat ? 1.75 : 1.55, yaw);
  }

  function meeting(x, z, yaw, cloth) {
    const group = new THREE.Group();
    group.position.set(x, 0, z);
    group.rotation.y = yaw;
    part(group, 2.4, 0.08, 1.25, 0, FLOOR + 0.76, 0, mats.desk);
    for (const [lx, lz] of [
      [-1.02, -0.46],
      [1.02, -0.46],
      [-1.02, 0.46],
      [1.02, 0.46],
    ]) {
      part(group, 0.1, 0.68, 0.1, lx, FLOOR + 0.36, lz, mats.wood);
    }
    scene.add(group);
    addAABB(x, z, 2.45, 1.3, yaw);
    const seats = [
      [0, 1.12, 0],
      [0, -1.12, Math.PI],
      [1.42, 0, -Math.PI / 2],
      [-1.42, 0, Math.PI / 2],
    ];
    for (const [lx, lz, turn] of seats) {
      const [wx, wz] = localToWorld(x, z, yaw, lx, lz);
      chair(wx, wz, yaw + turn, cloth);
    }
  }

  function workTable(x, z, w, d, yaw = 0) {
    const group = new THREE.Group();
    group.position.set(x, 0, z);
    group.rotation.y = yaw;
    part(group, w, 0.09, d, 0, FLOOR + 0.76, 0, mats.desk);
    const ix = w / 2 - 0.14;
    const iz = d / 2 - 0.14;
    for (const [lx, lz] of [
      [-ix, -iz],
      [ix, -iz],
      [-ix, iz],
      [ix, iz],
    ]) {
      part(group, 0.1, 0.72, 0.1, lx, FLOOR + 0.36, lz, mats.woodDeep);
    }
    scene.add(group);
    addAABB(x, z, w + 0.05, d + 0.05, yaw);
  }

  function bench(x, z, yaw) {
    const group = new THREE.Group();
    group.position.set(x, 0, z);
    group.rotation.y = yaw;
    part(group, 1.55, 0.08, 0.46, 0, FLOOR + 0.46, 0, mats.wood);
    part(group, 1.55, 0.4, 0.08, 0, FLOOR + 0.72, -0.2, mats.woodDeep);
    part(group, 0.08, 0.42, 0.4, -0.68, FLOOR + 0.21, 0, mats.woodDeep);
    part(group, 0.08, 0.42, 0.4, 0.68, FLOOR + 0.21, 0, mats.woodDeep);
    scene.add(group);
    addAABB(x, z, 1.6, 0.55, yaw);
  }

  const lamps = [];
  function lamp(x, z, color = 0xffb15a, intensity = 11) {
    const shade = new THREE.Mesh(
      new THREE.SphereGeometry(0.18, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.48),
      new THREE.MeshStandardMaterial({
        color: 0xfff6ea,
        emissive: color,
        emissiveIntensity: 0.62,
        roughness: 0.5,
        side: THREE.DoubleSide,
      }),
    );
    shade.position.set(x, 4.38, z);
    const bulb = new THREE.Mesh(
      new THREE.SphereGeometry(0.07, 14, 10),
      new THREE.MeshStandardMaterial({
        color: 0xfffaf4,
        emissive: color,
        emissiveIntensity: 1.45,
        roughness: 0.28,
      }),
    );
    bulb.position.set(x, 4.2, z);
    const cord = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.7, 6), mats.woodDeep);
    cord.position.set(x, 4.62, z);
    const light = new THREE.PointLight(color, intensity, 11, 1.8);
    light.position.set(x, 4.02, z);
    light.userData.base = intensity;
    lamps.push(light);
    scene.add(shade, bulb, cord, light);
  }

  function barLamp(x, z, color, intensity, length = 3.2) {
    const y = 5.78;
    const group = new THREE.Group();
    group.position.set(x, y, z);
    const metal = std(0xf6f1ea, 0.42);
    const housing = new THREE.Mesh(new THREE.BoxGeometry(length, 0.07, 0.18), metal);
    housing.castShadow = true;
    const diffuser = new THREE.Mesh(
      new THREE.BoxGeometry(length - 0.18, 0.03, 0.1),
      new THREE.MeshStandardMaterial({
        color: 0xfff7ee,
        emissive: color,
        emissiveIntensity: 0.95,
        roughness: 0.32,
      }),
    );
    diffuser.position.y = -0.046;
    const capGeo = new THREE.BoxGeometry(0.055, 0.09, 0.2);
    const capL = new THREE.Mesh(capGeo, mats.woodDeep);
    capL.position.x = -length / 2 + 0.02;
    const capR = capL.clone();
    capR.position.x = length / 2 - 0.02;
    const rise = 0.62;
    const rail = new THREE.Mesh(new THREE.BoxGeometry(length * 0.72, 0.03, 0.045), metal);
    rail.position.y = rise;
    const stemGeo = new THREE.CylinderGeometry(0.012, 0.012, rise, 6);
    const stemL = new THREE.Mesh(stemGeo, metal);
    stemL.position.set(-length * 0.28, rise / 2, 0);
    const stemR = stemL.clone();
    stemR.position.x = length * 0.28;
    group.add(housing, diffuser, capL, capR, rail, stemL, stemR);
    scene.add(group);
    [-0.32, 0, 0.32].forEach((offset, index) => {
      const strength = index === 1 ? intensity : intensity * 0.72;
      const light = new THREE.PointLight(color, strength, 13, 1.65);
      light.position.set(x + offset * length, y - 0.16, z);
      light.userData.base = strength;
      lamps.push(light);
      scene.add(light);
    });
  }

  function ripple(x, z, phase, color = 0xffffff) {
    const mat = new THREE.MeshBasicMaterial({
      color,
      transparent: true,
      opacity: 0.25,
      depthWrite: false,
    });
    const mesh = new THREE.Mesh(new THREE.TorusGeometry(1, 0.011, 6, 28), mat);
    mesh.rotation.x = Math.PI / 2;
    mesh.position.set(x, 0.085, z);
    scene.add(mesh);
    ripples.push({ mesh, mat, phase });
  }

  // Sky, sun, and a little weather.
  const skyCanvas = document.createElement("canvas");
  skyCanvas.width = 8;
  skyCanvas.height = 512;
  const skyG = skyCanvas.getContext("2d");
  const skyTex = new THREE.CanvasTexture(skyCanvas);
  skyTex.colorSpace = THREE.SRGBColorSpace;
  const paintSky = (stops) => {
    const gradient = skyG.createLinearGradient(0, 0, 0, 512);
    stops.forEach(([offset, color]) => gradient.addColorStop(offset, color));
    skyG.fillStyle = gradient;
    skyG.fillRect(0, 0, 8, 512);
    skyTex.needsUpdate = true;
  };
  paintSky([
    [0, "#8ebbe8"],
    [0.22, "#d7e7f6"],
    [0.48, "#f8e6da"],
    [1, "#f4cbb6"],
  ]);
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(88, 24, 16),
    new THREE.MeshBasicMaterial({ map: skyTex, side: THREE.BackSide, depthWrite: false, fog: false }),
  );
  sky.renderOrder = -2;
  scene.add(sky);

  const sunMesh = new THREE.Mesh(
    new THREE.SphereGeometry(4.8, 20, 14),
    new THREE.MeshBasicMaterial({ color: 0xffe6c0, fog: false }),
  );
  sunMesh.position.set(-28, 16, -26);
  scene.add(sunMesh);

  const cloudMat = new THREE.MeshBasicMaterial({
    color: 0xfffaf7,
    transparent: true,
    opacity: 0.82,
    depthWrite: false,
    fog: false,
  });
  [
    [-16, 9.5, -20, 6.2, 1.15, 2.6],
    [-4, 11, -30, 7.2, 1.1, 2.8],
    [12, 8.8, -18, 5.4, 1.05, 2.2],
    [18, 10.5, -6, 6, 1.1, 2.4],
    [-22, 9, 4, 5.2, 1, 2.2],
  ].forEach(([x, y, z, sx, sy, sz], index) => {
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 8), cloudMat);
    mesh.position.set(x, y, z);
    mesh.scale.set(sx, sy, sz);
    scene.add(mesh);
    clouds.push({ mesh, base: x, phase: index * 1.3 });
  });

  const hemi = new THREE.HemisphereLight(0xfff4e6, 0xecd4b4, 1.35);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xfff1dc, 2.6);
  sun.position.set(-16, 28, -22);
  sun.target.position.set(0, 0, 2);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.near = 0.5;
  sun.shadow.camera.far = 90;
  sun.shadow.camera.left = -36;
  sun.shadow.camera.right = 36;
  sun.shadow.camera.top = 36;
  sun.shadow.camera.bottom = -36;
  sun.shadow.bias = -0.00045;
  sun.shadow.normalBias = 0.045;
  scene.add(sun, sun.target);
  const fill = new THREE.DirectionalLight(0xfff0e4, 0.55);
  fill.position.set(18, 12, 14);
  scene.add(fill);

  // Ground and building shell. -Z is north, toward the garden.
  floor(0, -2, 120, 120, mats.grass, 0);
  floor(0, 3, 35.2, 22.3, mats.pad, 0.02);

  const openings = [
    { x: -14.3, z: -8, y: 1.9, w: 1.5, h: 1.22 },
    { x: -10.2, z: -8, y: 1.9, w: 1.5, h: 1.22 },
    { x: 10.2, z: -8, y: 1.9, w: 1.5, h: 1.22 },
    { x: 14.3, z: -8, y: 1.9, w: 1.5, h: 1.22 },
    { x: -17.5, z: -5.4, y: 1.85, w: 1.32, h: 1.18 },
    { x: -17.5, z: 6.5, y: 1.85, w: 1.32, h: 1.18 },
    { x: 6, z: -4.4, y: 1.72, w: 1.7, h: 1.7 },
    { x: 17.5, z: -6.3, y: 1.85, w: 1.32, h: 1.18 },
    { x: 17.5, z: -4.2, y: 1.85, w: 1.32, h: 1.18 },
    { x: 17.5, z: 4.4, y: 1.85, w: 1.32, h: 1.18 },
    { x: 17.2, z: 8.35, y: 1.72, w: 1.55, h: 1.85 },
    { x: 17.5, z: 8.35, y: 1.72, w: 1.55, h: 1.85 },
    { x: 9.05, z: 10.4, y: 1.7, w: 1.7, h: 1.8 },
    { x: 15.35, z: 10.4, y: 1.7, w: 2.25, h: 1.85 },
    { x: -12, z: 14, y: 2.2, w: 4.6, h: 2.7 },
  ];
  wallXGaps(-17.5, -8.5, 14, openings);
  wallXGaps(17.5, -8.5, 14, openings);
  wallZGaps(-8, -18.3, -1.65, openings);
  wallZGaps(-8, 1.65, 18.3, openings);
  solid(3.4, 0.14, T, 0, 2.32, -8, mats.wall, false, true);

  wallXGaps(6, -8, -1.55, openings);
  wallX(6, 1.55, 6);
  wallX(-6, -8, -1.55);
  wallX(-6, 1.55, 6);
  solid(T, 0.14, 3.1, 6, 2.47, 0, mats.wall, false, true);
  solid(T, 0.14, 3.1, -6, 2.47, 0, mats.wall, false, true);

  wallZ(6, -17.5, -6);
  wallZ(6, 6, 17.5);
  solid(11.2, 0.14, T, 0, 2.49, 6, mats.wall, false, true);

  // Two compact rental offices. The rest of this wing is an open project deck.
  wallX(6, 6, 7.45);
  wallX(6, 9.5, 10.4);
  wallX(10.6, 6.15, 10.4);
  wallX(12.35, 6.15, 7.35);
  wallX(12.35, 9.25, 10.4);
  wallXGaps(17.2, 6.15, 10.4, openings);
  wallZGaps(10.4, 12.35, 17.2, openings);
  wallZGaps(10.4, 6, 10.6, openings);
  wallX(-6, 6, 8.65);
  wallX(-6, 11.55, 14);
  wallZGaps(14, -17.5, -6, openings);
  solid(12, 0.62, T, 0, 0.31, 14, mats.trim, false, true);
  solid(11.4, 0.62, T, 11.7, 0.31, 14, mats.trim, false, true);

  solid(36.9, 1.02, 0.52, 0, 0.51, -23.95, mats.hedge, true, true);
  solid(0.55, 1.02, 12.1, 18.15, 0.51, -17.85, mats.hedge, true, true);
  solid(0.55, 1.02, 12.1, -18.15, 0.51, -17.85, mats.hedge, true, true);

  floor(0, -1.1, 11.3, 12.6, mats.plank, 0.034);
  floor(11.75, -1.1, 10.7, 12.6, mats.plank, 0.034);
  floor(-11.75, -1.1, 10.7, 12.6, mats.plank, 0.034);
  floor(0, 10, 11.2, 7.2, mats.plank, 0.034);
  floor(8.3, 8.25, 4.15, 3.85, mats.plank, 0.034);
  floor(14.75, 8.25, 4.55, 3.85, mats.plank, 0.034);
  floor(11.7, 12.2, 10.6, 3.15, mats.plank, 0.034);
  floor(-11.75, 10, 10.6, 7.2, mats.plank, 0.034);
  function skirt(x, z, w, d) {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, 0.12, d), mats.trim);
    mesh.position.set(x, 0.06, z);
    mesh.receiveShadow = true;
    scene.add(mesh);
  }
  skirt(-3.7, -7.74, 3.6, 0.06);
  skirt(3.7, -7.74, 3.6, 0.06);
  skirt(11.9, -7.74, 10.6, 0.06);
  skirt(-11.9, -7.74, 10.6, 0.06);
  skirt(11.9, 5.78, 10.6, 0.06);
  skirt(-11.9, 5.78, 10.6, 0.06);
  skirt(17.28, -1.1, 0.06, 12.2);
  skirt(-17.28, -1.1, 0.06, 12.2);
  disc(0, 0.2, 1.7, paper(medallionTexture(anisotropy)), 0.05, 48);

  solid(35.2, 0.1, 13.5, 0, WALL_H - 0.04, -1.15, mats.ceil, false, false);
  solid(11.2, 0.1, 7.5, -11.75, WALL_H - 0.04, 10, mats.ceil, false, false);
  solid(11.0, 0.1, 4.15, 11.6, WALL_H - 0.04, 8.25, mats.ceil, false, false);
  solid(35.6, 0.18, 14.0, 0, WALL_H + 0.16, -1.05, mats.roof, false, false);
  solid(11.5, 0.18, 7.9, -11.75, WALL_H + 0.16, 10, mats.roof, false, false);
  solid(11.2, 0.18, 4.35, 11.6, WALL_H + 0.16, 8.25, mats.roof, false, false);

  openings.forEach((hole) => {
    const side = Math.abs(hole.x) > 16 || hole.x === 6;
    windowAt(hole.x, hole.y, hole.z, side ? -Math.PI / 2 : 0, hole.w, hole.h);
  });
  function cottage(x, z, yaw) {
    const group = new THREE.Group();
    group.position.set(x, 0, z);
    group.rotation.y = yaw;
    part(group, 2.5, 3.7, 1.65, 0, 1.85, 0, mats.lobby);
    part(group, 2.8, 0.12, 1.95, 0, 3.78, 0, mats.gold);
    part(group, 2.15, 0.78, 1.35, 0, 4.25, 0, mats.woodDeep);
    const paneMat = new THREE.MeshBasicMaterial({ color: 0xd7ebf4 });
    [[-0.58, 1.55], [0.58, 1.55], [-0.58, 2.7], [0.58, 2.7]].forEach(([lx, ly]) => {
      const win = new THREE.Mesh(new THREE.PlaneGeometry(0.46, 0.7), paneMat);
      win.position.set(lx, ly, 0.86);
      group.add(win);
    });
    const door = new THREE.Mesh(new THREE.PlaneGeometry(0.48, 0.92), mats.woodDeep);
    door.position.set(0, 0.7, 0.85);
    const awning = new THREE.Mesh(new THREE.BoxGeometry(1.05, 0.05, 0.42), mats.wine);
    awning.position.set(0, 1.32, 1.02);
    group.add(door, awning);
    scene.add(group);
    addAABB(x, z, 2.5, 1.65, yaw);
  }
  [
    [11.2, -9.7, 0.7, true],
    [14.6, -10.05, 0.75, false],
    [-11.1, -9.75, 0.7, true],
    [-14.7, -10.0, 0.72, false],
    [20.85, -1.1, 0.68, true],
    [20.85, 7.1, 0.66, false],
    [-20.85, -1.4, 0.68, true],
    [-20.85, 7.4, 0.66, true],
  ].forEach(([x, z, s, blossom]) => plant(x, z, s, blossom));
  cottage(21.4, -6.3, -Math.PI / 2);
  cottage(21.5, -4.1, -Math.PI / 2);
  cottage(21.4, 4.5, -Math.PI / 2);
  cottage(21.3, 9.2, -Math.PI / 2);
  tree(10.2, -11.3, 1.25, true);
  tree(-10.3, -11.4, 1.2, true);
  [-1, 1].forEach((side) => {
    floor(side * 19.25, 2.05, 2.35, 26.5, mats.pad, 0.042);
    floor(side * 16.4, -10.15, 5.6, 2.15, mats.pad, 0.042);
    lantern(side * 20.7, -10.1);
    lantern(side * 20.7, 12.4);
  });
  register(19.25, -9.2, 2.4, {
    title: "Outside path",
    ko: "바깥 산책로",
    body: "Walk outside the building. The garden is one way, the sea is the other.",
    bodyKo: "건물 밖으로 이어진 길이에요. 한쪽은 정원, 다른 쪽은 바다예요.",
  });
  register(-19.25, -9.2, 2.4, {
    title: "Outside path",
    ko: "바깥 산책로",
    body: "Walk outside the building. The garden is one way, the sea is the other.",
    bodyKo: "건물 밖으로 이어진 길이에요. 한쪽은 정원, 다른 쪽은 바다예요.",
  });
  cottage(-21.4, -5.4, Math.PI / 2);
  cottage(-21.5, 6.5, Math.PI / 2);

  lamp(0, -3.3, 0xffc56b, 11);
  lamp(0, 3.5, 0xffc56b, 11);
  lamp(12, -2.6, 0xff8a3d, 10);
  lamp(12, 2.4, 0xff8a3d, 10);
  lamp(15.6, 0.15, 0xff8a3d, 10);
  lamp(-12.2, -2.2, 0xc4b0ff, 10);
  lamp(-12.2, 2.6, 0xc4b0ff, 10);
  lamp(8.4, 8.3, 0xff8eae, 8.5);
  lamp(14.9, 8.3, 0xff7a5c, 8.5);
  lamp(12.2, 12.3, 0xffd7a8, 7.5);
  lamp(-12.2, 10.2, 0x9ebfff, 10);

  // Hanging Rose Morning sign.
  const heroMat = paper(heroTexture(anisotropy));
  const hero = new THREE.Group();
  hero.position.set(0, 2.48, 0.55);
  const heroFrame = new THREE.Mesh(new THREE.BoxGeometry(3.95, 1.42, 0.08), mats.dusty);
  heroFrame.castShadow = true;
  const heroFront = new THREE.Mesh(new THREE.PlaneGeometry(3.78, 1.26), heroMat);
  heroFront.position.z = 0.045;
  const heroBack = new THREE.Mesh(new THREE.PlaneGeometry(3.78, 1.26), heroMat);
  heroBack.position.z = -0.045;
  heroBack.rotation.y = Math.PI;
  hero.add(heroFrame, heroFront, heroBack);
  scene.add(hero);
  solid(0.03, 1.5, 0.03, -1.55, 3.95, 0.55, mats.woodDeep, false, false);
  solid(0.03, 1.5, 0.03, 1.55, 3.95, 0.55, mats.woodDeep, false, false);
  register(0, 0.55, 2.5, {
    title: "Rose Morning",
    ko: "로즈 모닝",
    body: "Bright minds. Beautiful mornings. A city campus for group English, AI study, and small offices.",
    bodyKo: "밝은 마음, 아름다운 아침. 그룹 영어, AI 공부, 작은 사무실이 있는 시티 캠퍼스.",
  });

  const welcome = posterTexture({
    title: "Welcome",
    ko: "환영합니다",
    kicker: "ROSE MORNING",
    blocks: [
      {
        en: ["Group English, AI study,", "and offices you can rent."],
        ko: ["그룹 영어, AI 공부,", "그리고 빌릴 수 있는 사무실."],
      },
    ],
  }, anisotropy);
  panel(
    -5.68,
    1.55,
    2.45,
    Math.PI / 2,
    0.86,
    1.08,
    paper(welcome),
    mats.trim,
  );
  register(-5.2, 2.45, 2.1, {
    title: "Welcome",
    ko: "환영합니다",
    body: "Group English, AI study, and offices you can rent. The map is on the left wall.",
    bodyKo: "그룹 영어, AI 공부, 그리고 빌릴 수 있는 사무실. 지도는 왼쪽 벽에 있어요.",
  });

  panel(
    -5.72,
    1.62,
    4.15,
    Math.PI / 2,
    1.65,
    2.05,
    paper(mapTexture(anisotropy)),
    mats.trim,
  );
  register(-5.3, 4.15, 2.1, {
    title: "Campus map",
    ko: "캠퍼스 지도",
    body: "Garden to the north. English classroom to the east. AI lounge to the west. Small offices and the sea to the south.",
    bodyKo: "북쪽은 정원, 동쪽은 영어 교실, 서쪽은 AI 라운지, 남쪽은 작은 사무실과 바다예요.",
  });

  solid(2.4, 0.92, 0.7, -4.45, FLOOR + 0.46, -7.2, mats.wood, true, true);
  const porcelain = std(0xfffbf7, 0.28);
  const plateWell = std(0xf4ebe3, 0.32);
  const rimGold = std(0xc9a36a, 0.32, { metalness: 0.42 });
  const dough = std(0xf0d2a8, 0.58);
  const cream = std(0xfff6ee, 0.38);
  const petalPink = std(0xe7b7c6, 0.42);
  const petalLight = std(0xf6d5de, 0.38);
  const roseHeart = std(0xc45d73, 0.35);
  const madeleineGold = std(0xe6c887, 0.46);
  const sugar = std(0xf8edd4, 0.32);
  const berryRed = std(0xc4455c, 0.42);
  const berryDark = std(0x6d3058, 0.4);
  const leafGreen = std(0x6f9a62, 0.5);
  const sesame = std(0xc4a06a, 0.48);
  const choc = std(0x5a382c, 0.38);
  const crust = std(0xe2c08a, 0.55);
  const biscuitMat = std(0xd7b98a, 0.52);

  function addPlate(group) {
    const dish = new THREE.Mesh(new THREE.CylinderGeometry(0.148, 0.128, 0.02, 32), porcelain);
    dish.position.y = 0.012;
    const well = new THREE.Mesh(new THREE.CylinderGeometry(0.098, 0.098, 0.01, 24), plateWell);
    well.position.y = 0.02;
    const rim = new THREE.Mesh(new THREE.TorusGeometry(0.14, 0.011, 8, 36), rimGold);
    rim.rotation.x = Math.PI / 2;
    rim.position.y = 0.02;
    group.add(dish, well, rim);
  }

  [
    { en: "Rose cookie", ko: "장미 쿠키" },
    { en: "Gold madeleine", ko: "골드 마들렌" },
    { en: "Cream bun", ko: "크림 빵" },
    { en: "Berry tart", ko: "베리 타르트" },
    { en: "Tea biscuit", ko: "차 비스킷" },
  ].forEach((item, index) => {
    const group = new THREE.Group();
    const x = -5.25 + index * 0.4;
    const z = -7.16;
    group.position.set(x, FLOOR + 0.92, z);
    addPlate(group);
    const food = new THREE.Group();
    food.position.y = -0.012;
    group.add(food);
    if (index === 0) {
      const cookie = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.094, 0.026, 24), dough);
      cookie.position.y = 0.042;
      food.add(cookie);
      for (let i = 0; i < 8; i += 1) {
        const petal = new THREE.Mesh(new THREE.SphereGeometry(0.02, 8, 6), petalPink);
        const angle = (i / 8) * Math.PI * 2;
        petal.position.set(Math.cos(angle) * 0.036, 0.062, Math.sin(angle) * 0.036);
        petal.scale.set(1.25, 0.65, 0.85);
        food.add(petal);
      }
      for (let i = 0; i < 5; i += 1) {
        const petal = new THREE.Mesh(new THREE.SphereGeometry(0.014, 8, 6), petalLight);
        const angle = (i / 5) * Math.PI * 2 + 0.4;
        petal.position.set(Math.cos(angle) * 0.016, 0.074, Math.sin(angle) * 0.016);
        food.add(petal);
      }
      const heart = new THREE.Mesh(new THREE.SphereGeometry(0.011, 8, 6), roseHeart);
      heart.position.y = 0.086;
      food.add(heart);
    } else if (index === 1) {
      const shell = new THREE.Mesh(
        new THREE.SphereGeometry(0.086, 18, 12, 0, Math.PI * 2, 0, Math.PI * 0.55),
        madeleineGold,
      );
      shell.scale.set(1.45, 0.48, 0.92);
      shell.position.y = 0.05;
      food.add(shell);
      for (let i = -2; i <= 2; i += 1) {
        const ridge = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.012, 0.11), std(0xc9964e, 0.42));
        ridge.position.set(i * 0.022, 0.09, 0);
        ridge.rotation.x = -0.35;
        food.add(ridge);
      }
    } else if (index === 2) {
      const bun = new THREE.Mesh(new THREE.SphereGeometry(0.08, 18, 14), dough);
      bun.scale.set(1.08, 0.68, 1.05);
      bun.position.y = 0.072;
      const split = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.008, 0.012), std(0xd8b48a, 0.5));
      split.position.y = 0.08;
      food.add(bun, split);
      [
        [0.018, 0.108, 0.004, 0.026],
        [-0.012, 0.116, 0.012, 0.02],
        [0.004, 0.126, -0.008, 0.016],
        [0, 0.134, 0, 0.012],
      ].forEach(([sx, sy, sz, radius]) => {
        const blob = new THREE.Mesh(new THREE.SphereGeometry(radius, 10, 8), cream);
        blob.position.set(sx, sy, sz);
        food.add(blob);
      });
      for (let i = 0; i < 7; i += 1) {
        const seed = new THREE.Mesh(new THREE.SphereGeometry(0.006, 6, 5), sesame);
        const angle = (i / 7) * Math.PI * 2;
        seed.position.set(Math.cos(angle) * 0.048, 0.092, Math.sin(angle) * 0.042);
        food.add(seed);
      }
    } else if (index === 3) {
      const shell = new THREE.Mesh(new THREE.CylinderGeometry(0.078, 0.068, 0.034, 18), crust);
      shell.position.y = 0.044;
      const filling = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.014, 16), cream);
      filling.position.y = 0.06;
      food.add(shell, filling);
      [
        [0, 0.078, 0, 0.02, berryRed],
        [0.028, 0.074, 0.016, 0.015, berryDark],
        [-0.026, 0.074, 0.012, 0.015, berryRed],
        [0.008, 0.074, -0.026, 0.014, std(0x8e3a55, 0.4)],
        [-0.01, 0.072, 0.028, 0.013, berryDark],
      ].forEach(([bx, by, bz, radius, material]) => {
        const berry = new THREE.Mesh(new THREE.SphereGeometry(radius, 8, 6), material);
        berry.position.set(bx, by, bz);
        food.add(berry);
      });
      const mint = new THREE.Mesh(new THREE.SphereGeometry(0.015, 8, 6), leafGreen);
      mint.scale.set(1.7, 0.32, 0.75);
      mint.position.set(0.038, 0.08, -0.018);
      mint.rotation.y = 0.7;
      food.add(mint);
    } else {
      const biscuit = new THREE.Mesh(new THREE.CylinderGeometry(0.084, 0.084, 0.024, 22), biscuitMat);
      biscuit.position.y = 0.04;
      const glaze = new THREE.Mesh(new THREE.CylinderGeometry(0.066, 0.066, 0.008, 20), sugar);
      glaze.position.y = 0.054;
      food.add(biscuit, glaze);
      [
        [0, 0],
        [0.026, 0.01],
        [-0.024, 0.014],
        [0.01, -0.028],
        [-0.016, -0.02],
        [0.032, -0.016],
        [-0.032, -0.006],
      ].forEach(([px, pz]) => {
        const hole = new THREE.Mesh(new THREE.CylinderGeometry(0.005, 0.005, 0.006, 6), choc);
        hole.position.set(px, 0.06, pz);
        food.add(hole);
      });
    }
    group.traverse((mesh) => {
      if (mesh.isMesh) mesh.castShadow = true;
    });
    scene.add(group);
    snacks.push({ ...item, x, z, mesh: group, taken: false });
  });
  panel(-4.45, 2.05, -7.72, 0, 1.7, 0.78, paper(headerTexture("Morning pantry", "아침 팬트리", anisotropy)));
  register(-4.45, -6.55, 2.1, {
    title: "Morning pantry",
    ko: "아침 팬트리",
    body: "Press F or the Pick up button to take a snack. It stays in your bag for this visit.",
    bodyKo: "F 또는 집기 버튼으로 과자를 집어요. 이번 방문 동안 가방에 남아요.",
  });

  const wallNote = (x, y, z, yaw, title, ko, enLines, koLines, body, bodyKo) => {
    panel(
      x,
      y,
      z,
      yaw,
      0.78,
      1.02,
      paper(posterTexture({
        title,
        ko,
        titleSize: 58,
        koSize: 40,
        blocks: [{ en: enLines, ko: koLines }],
      }, anisotropy)),
      mats.trim,
    );
    register(x, z, 2.1, { title, ko, body, bodyKo });
  };

  panel(5.72, 2.85, 0, -Math.PI / 2, 2.4, 0.66, paper(headerTexture("English classroom", "영어 교실", anisotropy)));
  panel(6.28, 2.85, 0, Math.PI / 2, 1.8, 0.55, paper(headerTexture("Lobby", "로비", anisotropy)));
  wallNote(
    5.78,
    1.5,
    2.2,
    -Math.PI / 2,
    "English classroom",
    "영어 교실",
    ["Nine desks, one whiteboard,", "and a lesson you share."],
    ["아홉 자리, 하나의 칠판,", "함께 여는 수업."],
    "Nine desks, one whiteboard, and a lesson you share.",
    "아홉 자리, 하나의 칠판, 함께 여는 수업.",
  );

  panel(-5.72, 2.85, 0, Math.PI / 2, 2.4, 0.66, paper(headerTexture("AI study lounge", "AI 공부 라운지", anisotropy)));
  panel(-6.28, 2.85, 0, -Math.PI / 2, 1.8, 0.55, paper(headerTexture("Lobby", "로비", anisotropy)));
  register(-5.4, 0.2, 2.2, {
    title: "AI study lounge",
    ko: "AI 공부 라운지",
    body: "Prompts on the screens. Talk them through together. No account needed.",
    bodyKo: "화면의 질문으로 함께 이야기해 보세요. 계정은 필요 없어요.",
  });


  plant(5.05, 4.85, 1.55);
  plant(5.15, -6.35, 1.45, true);
  plant(-4.15, 5.48, 1.55);

  // English classroom, nine desks facing the east whiteboard.
  const boards = [];
  {
    const boardCanvas = document.createElement("canvas");
    boardCanvas.width = 2048;
    boardCanvas.height = 1152;
    const boardCtx = boardCanvas.getContext("2d");
    const boardTex = new THREE.CanvasTexture(boardCanvas);
    boardTex.colorSpace = THREE.SRGBColorSpace;
    boardTex.anisotropy = anisotropy;
    const notes = [];
    const drawBoard = () => {
      boardCtx.fillStyle = "#F7FBFC";
      boardCtx.fillRect(0, 0, 2048, 1152);
      boardCtx.strokeStyle = "#E7DCC8";
      boardCtx.lineWidth = 3;
      for (let line = 150; line < 1100; line += 112) {
        boardCtx.beginPath();
        boardCtx.moveTo(70, line);
        boardCtx.lineTo(1980, line);
        boardCtx.stroke();
      }
      const lesson = [
        ["Good morning.", "#2E2420", "700 78px Fraunces, serif"],
        ["좋은 아침이에요.", "#7A6A5E", "600 46px 'Noto Sans KR', sans-serif"],
        ["I'm ____.", "#2E2420", "700 68px Fraunces, serif"],
        ["저는 ____ 입니다.", "#7A6A5E", "600 42px 'Noto Sans KR', sans-serif"],
        ["Nice to meet you.", "#2E2420", "700 60px Fraunces, serif"],
        ["만나서 반가워요.", "#7A6A5E", "600 42px 'Noto Sans KR', sans-serif"],
      ];
      boardCtx.textAlign = "left";
      boardCtx.textBaseline = "middle";
      lesson.forEach((row, index) => {
        boardCtx.fillStyle = row[1];
        boardCtx.font = row[2];
        boardCtx.fillText(row[0], 110, 170 + index * 130);
      });
      boardCtx.fillStyle = "#6E1F2A";
      boardCtx.font = "700 36px Nunito, sans-serif";
      boardCtx.fillText("Your notes", 1180, 150);
      boardCtx.font = "600 32px 'Noto Sans KR', sans-serif";
      boardCtx.fillText("우리 글", 1180, 200);
      notes.slice(-7).forEach((note, index) => {
        boardCtx.fillStyle = note.color;
        boardCtx.font = "600 48px Nunito, 'Noto Sans KR', sans-serif";
        boardCtx.fillText(note.text, 1180, 300 + index * 100);
      });
      boardTex.needsUpdate = true;
    };
    drawBoard();
    const boardMat = new THREE.MeshStandardMaterial({
      map: boardTex,
      roughness: 0.9,
      emissive: new THREE.Color("#fffaf6"),
      emissiveMap: boardTex,
      emissiveIntensity: 0.16,
    });
    panel(17.18, 1.72, -0.35, -Math.PI / 2, 3.55, 1.95, boardMat, mats.wood);
    boards.push({
      x: 15.6,
      z: -0.35,
      r: 2.5,
      add(text, color) {
        const clean = text.trim().slice(0, 22);
        if (!clean) return false;
        notes.push({ text: clean, color: color || "#2E2420" });
        if (notes.length > 7) notes.shift();
        drawBoard();
        return true;
      },
    });
  }
  const deskX = [9.0, 11.7, 14.35];
  const deskZ = [-4.4, -1.35, 1.7];
  let deskIndex = 0;
  for (const z of deskZ) {
    for (const x of deskX) {
      studentDesk(x, z, Math.PI / 2, deskIndex);
      deskIndex += 1;
    }
  }
  workTable(15.55, 4.05, 2.3, 1.15);
  panel(15.55, 1.15, 4.7, Math.PI, 1.5, 0.42, paper(headerTexture("Project table", "프로젝트 테이블", anisotropy)));
  plant(15.6, 5.45, 0.72);
  plant(7.35, -6.7, 0.75);

  // AI study lounge.
  panel(-17.18, 1.78, -0.8, Math.PI / 2, 4.3, 2.35, new THREE.MeshBasicMaterial({ map: aiWallTexture(anisotropy) }), mats.lilac);
  const prompts = [
    ["What do we know?", "무엇을 알고 있나요?"],
    ["Who is this for?", "누구를 위한 건가요?"],
    ["How can I help you?", "무엇을 도와드릴까요?"],
  ];
  prompts.forEach((item, index) => {
    const x = -15.2 + index * 3.05;
    studentDesk(x, -5.85, Math.PI, index + 1, true);
    const laptop = new THREE.Group();
    laptop.position.set(x, 0.84, -5.85);
    laptop.rotation.y = Math.PI;
    const base = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.018, 0.32), mats.desk);
    base.position.set(0, 0.01, 0);
    const screen = new THREE.Mesh(
      new THREE.PlaneGeometry(0.42, 0.28),
      new THREE.MeshBasicMaterial({ map: promptTexture(item[0], item[1], anisotropy) }),
    );
    screen.rotation.order = "YXZ";
    screen.rotation.y = Math.PI;
    screen.rotation.x = -0.42;
    screen.position.set(0, 0.2, -0.02);
    laptop.add(base, screen);
    scene.add(laptop);
  });
  sofa(-14.6, 4.85, Math.PI, 1.7, mats.rose);
  sofa(-11.4, 4.85, Math.PI, 1.7, mats.sage);
  workTable(-12.4, 2.15, 2.6, 1.3);
  panel(-12.4, 1.15, 2.9, Math.PI, 1.7, 0.42, paper(headerTexture("Build together", "함께 만들기", anisotropy)));
  workTable(-8.9, 4.25, 1.9, 0.95);
  solid(0.22, 0.22, 0.22, -9.1, FLOOR + 0.86, 4.35, mats.butter, false, true);
  solid(0.18, 0.28, 0.18, -8.7, FLOOR + 0.9, 4.5, mats.sage, false, true);
  const makerSphere = new THREE.Mesh(new THREE.SphereGeometry(0.12, 14, 10), mats.rose);
  makerSphere.position.set(-8.35, FLOOR + 0.87, 4.28);
  makerSphere.castShadow = true;
  scene.add(makerSphere);
  floor(-12.4, 0.2, 3.4, 2.2, mats.sage, 0.045);
  for (const [x, z] of [
    [-15.6, 1.4],
    [-10.6, 1.1],
    [-13.2, -0.7],
  ]) {
    const cushion = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.36, 0.1, 18), cloths[(x * 3) & 3] || mats.butter);
    cushion.position.set(x, FLOOR + 0.06, z);
    cushion.receiveShadow = true;
    scene.add(cushion);
  }
  plant(-16.4, 4.2, 0.9, true);
  plant(-16.5, -6.4, 0.8);

  // Rentable offices and the build-your-own room.
  const rentPoster = () =>
    paper(
      posterTexture(
        {
          w: 1280,
          h: 900,
          title: "Office for rent",
          ko: "사무실 대여",
          titleSize: 84,
          blocks: [
            {
              en: ["Seats four or five", "around one table."],
              ko: ["한 테이블에", "넷에서 다섯 명."],
            },
            {
              en: ["Ask in the lobby", "to use this room."],
              ko: ["이 방은 로비에서", "문의해 주세요."],
            },
          ],
        },
        anisotropy,
      ),
    );
  panel(10.38, 1.55, 8.3, -Math.PI / 2, 1.9, 1.25, rentPoster(), mats.gold);
  meetBoard(14.85, 1.72, 6.34, 0, "club-sea", 2.15, 1.28);
  panel(5.72, 2.7, 8.45, -Math.PI / 2, 1.7, 0.55, paper(headerTexture("Office for rent", "사무실 대여", anisotropy)));
  panel(14.7, 3.25, 10.18, 0, 1.7, 0.5, paper(headerTexture("Office for rent", "사무실 대여", anisotropy)));
  wallNote(
    5.78,
    1.5,
    6.85,
    -Math.PI / 2,
    "Office for rent",
    "사무실 대여",
    ["A club room for four or five.", "One table, five seats."],
    ["4-5인 동아리실.", "테이블 하나, 다섯 자리."],
    "Office for rent. A club room for four or five around one table.",
    "사무실 대여. 4-5인이 한 테이블에 앉는 동아리실.",
  );
  wallNote(
    12.14,
    1.5,
    9.7,
    -Math.PI / 2,
    "Office for rent",
    "사무실 대여",
    ["The second club room.", "Four or five seats."],
    ["두 번째 동아리실.", "넷에서 다섯 자리."],
    "Office for rent. The second club room, with seats for four or five.",
    "사무실 대여. 두 번째 동아리실. 넷에서 다섯 명이 앉아요.",
  );
  const clubRoom = (x, z) => {
    workTable(x, z, 2.15, 1.15);
    chair(x - 0.52, z - 1.02, 0, mats.rose);
    chair(x + 0.52, z - 1.02, 0, mats.butter);
    chair(x - 0.52, z + 1.02, Math.PI, mats.sage);
    chair(x + 0.52, z + 1.02, Math.PI, mats.sky);
    chair(x + 1.48, z, -Math.PI / 2, mats.dusty);
  };
  clubRoom(8.3, 8.2);
  clubRoom(14.9, 8.2);
  meetBoard(8.2, 1.78, 6.34, 0, "club-garden", 2.3, 1.32);
  meetBoard(-6.32, 1.72, 12.7, -Math.PI / 2, "ai-office", 2.05, 1.22);
  plant(6.75, 9.85, 0.62);
  plant(16.75, 6.6, 0.62, true);
  plant(12.7, 11.35, 0.7, true);
  plant(17.05, 11.15, 0.68);

  panel(
    -17.16,
    1.68,
    10.1,
    Math.PI / 2,
    3.15,
    1.95,
    paper(
      posterTexture(
        {
          w: 1400,
          h: 960,
          title: "Build your AI office",
          ko: "AI 사무실 만들기",
          blocks: [
            {
              en: ["A desk, a screen,", "and open floor."],
              ko: ["책상, 화면,", "그리고 비어 있는 바닥."],
            },
            {
              en: ["Sketch the workspace", "your group wants."],
              ko: ["모둠이 원하는 작업실을", "여기서 그려 보세요."],
            },
          ],
        },
        anisotropy,
      ),
    ),
    mats.gold,
  );
  plaque(
    -5.78,
    2.48,
    10.1,
    Math.PI / 2,
    1.45,
    0.4,
    paper(headerTexture("Build your AI office", "AI 사무실 만들기", anisotropy)),
  );
  plaque(
    -5.78,
    1.42,
    12.35,
    Math.PI / 2,
    0.86,
    1.15,
    paper(
      posterTexture(
        {
          title: "Build your AI office",
          ko: "AI 사무실 만들기",
          titleSize: 64,
          blocks: [
            {
              en: ["A desk, a screen,", "and open floor."],
              ko: ["책상, 화면,", "그리고 빈 바닥."],
            },
          ],
        },
        anisotropy,
      ),
    ),
  );
  register(-4.7, 12.35, 2.1, {
    title: "Build your AI office",
    ko: "AI 사무실 만들기",
    body: "Build your AI office. Start with a desk and a screen, then shape the rest.",
    bodyKo: "AI 사무실 만들기. 책상과 화면에서 시작하고, 나머지는 스스로 만들어요.",
  });
  studentDesk(-9.6, 8.15, -Math.PI / 2, 2);
  workTable(-13.2, 10.6, 2.5, 1.25);
  panel(
    -9.35,
    1.35,
    8.35,
    Math.PI / 2,
    0.7,
    0.48,
    new THREE.MeshBasicMaterial({
      map: promptTexture("Your office starts here", "여기서 사무실이 시작돼요", anisotropy),
    }),
  );
  const kitCube = solid(0.28, 0.28, 0.28, -14.05, FLOOR + 0.98, 10.6, mats.butter, false, true);
  snacks.push({ en: "Butter block", ko: "버터 블록", x: -14.05, z: 10.6, mesh: kitCube, taken: false });
  const kitSphere = new THREE.Mesh(new THREE.SphereGeometry(0.16, 14, 12), mats.rose);
  kitSphere.position.set(-13.45, FLOOR + 0.98, 10.45);
  kitSphere.castShadow = true;
  const kitCone = new THREE.Mesh(new THREE.ConeGeometry(0.15, 0.32, 12), mats.sage);
  kitCone.position.set(-12.85, FLOOR + 1.0, 10.7);
  kitCone.castShadow = true;
  const kitCyl = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.32, 12), mats.sky);
  kitCyl.position.set(-12.25, FLOOR + 0.98, 10.5);
  kitCyl.castShadow = true;
  scene.add(kitSphere, kitCone, kitCyl);
  snacks.push(
    { en: "Rose sphere", ko: "장미 구", x: -13.45, z: 10.45, mesh: kitSphere, taken: false },
    { en: "Leaf cone", ko: "잎 원뿔", x: -12.85, z: 10.7, mesh: kitCone, taken: false },
    { en: "Sky cylinder", ko: "하늘 기둥", x: -12.25, z: 10.5, mesh: kitCyl, taken: false },
  );
  const notebook = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.05, 0.22), mats.wine);
  notebook.position.set(15.15, FLOOR + 0.86, 3.85);
  notebook.castShadow = true;
  const marker = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.22, 8), mats.dusty);
  marker.rotation.z = Math.PI / 2;
  marker.position.set(15.7, FLOOR + 0.86, 4.15);
  marker.castShadow = true;
  scene.add(notebook, marker);
  snacks.push(
    { en: "Class notebook", ko: "수업 노트", x: 15.15, z: 3.85, mesh: notebook, taken: false },
    { en: "Marker", ko: "매직", x: 15.7, z: 4.15, mesh: marker, taken: false },
  );
  panel(-13.2, 1.45, 11.35, Math.PI, 1.55, 0.48, paper(headerTexture("Kit of parts", "부품 키트", anisotropy)));
  floor(-12.4, 10.5, 3.6, 2.4, mats.lilac, 0.046);
  plant(-16.45, 6.85, 0.85);

  // Open veranda. A high bar of light, not a low pendant.
  barLamp(0, 9.55, 0xff6a2e, 8.5, 3.4);
  lamp(-3.2, -14.2, 0xff9a45, 9.5);
  lamp(4.6, -17.4, 0xff9a45, 9.5);
  lamp(0, -11.2, 0xff9a45, 9);
  wallNote(
    -5.78,
    1.55,
    7.2,
    Math.PI / 2,
    "Sea terrace",
    "바다 테라스",
    ["The shore, then open water.", "A far line of the city."],
    ["모래밭 너머로 바다가 열려요.", "도시는 멀리 한 줄."],
    "Past the sand, the water opens into the sea. The city is only a line on the horizon.",
    "모래밭 너머로 바다가 열려요. 도시는 수평선 위의 한 줄이에요.",
  );
  plant(-5.25, 13.15, 0.72, true);
  plant(5.25, 13.15, 0.72);

  floor(0, 15.15, 72, 2.2, mats.sand, 0.05);
  const seaGeo = new THREE.PlaneGeometry(96, 52, 80, 36);
  seaGeo.rotateX(-Math.PI / 2);
  const seaPos = seaGeo.attributes.position;
  const seaBase = new Float32Array(seaPos.array);
  let seaNear = Infinity;
  let seaFar = -Infinity;
  for (let i = 0; i < seaPos.count; i += 1) {
    const z = seaPos.getZ(i);
    seaNear = Math.min(seaNear, z);
    seaFar = Math.max(seaFar, z);
  }
  const seaColors = new Float32Array(seaPos.count * 3);
  seaGeo.setAttribute("color", new THREE.BufferAttribute(seaColors, 3));
  const paintSea = (shallowHex, deepHex) => {
    const shallow = new THREE.Color(shallowHex);
    const deep = new THREE.Color(deepHex);
    for (let i = 0; i < seaPos.count; i += 1) {
      const t = (seaPos.getZ(i) - seaNear) / (seaFar - seaNear || 1);
      const color = shallow.clone().lerp(deep, t * t);
      seaColors[i * 3] = color.r;
      seaColors[i * 3 + 1] = color.g;
      seaColors[i * 3 + 2] = color.b;
    }
    seaGeo.attributes.color.needsUpdate = true;
  };
  paintSea("#7ecfc4", "#163e66");
  const sea = new THREE.Mesh(
    seaGeo,
    new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.18, metalness: 0.08 }),
  );
  sea.position.set(0, 0.1, 16.15 - seaNear);
  sea.receiveShadow = true;
  scene.add(sea);
  ripples.waves = { pos: seaPos, base: seaBase };
  const foam = new THREE.Mesh(
    new THREE.PlaneGeometry(70, 0.28),
    new THREE.MeshBasicMaterial({ color: 0xfffaf3, transparent: true, opacity: 0.7, depthWrite: false }),
  );
  foam.rotation.x = -Math.PI / 2;
  foam.position.set(0, 0.12, 16.05);
  scene.add(foam);

  function boat(x, z, yaw, hull) {
    const group = new THREE.Group();
    group.position.set(x, 0.14, z);
    group.rotation.y = yaw;
    part(group, 1.6, 0.22, 0.52, 0, 0.08, 0, hull);
    part(group, 0.36, 0.22, 0.3, -0.1, 0.26, 0, mats.desk);
    scene.add(group);
  }
  boat(-8, 22, 0.35, mats.wood);
  boat(6.5, 27, -0.5, mats.dusty);
  boat(-1.2, 33, 0.15, mats.wine);

  const horizon = sea.position.z + seaFar + 0.4;
  floor(0, horizon + 1.5, 70, 10, mats.sand, 0.2);
  const cityLights = [];
  const glowMat = () =>
    new THREE.MeshStandardMaterial({
      color: 0xffe7c2,
      emissive: 0xffb45a,
      emissiveIntensity: 0,
      roughness: 0.45,
      side: THREE.DoubleSide,
    });
  function apartment(x, h, w) {
    const z = horizon + 2.4;
    const body = mats.city[Math.abs(Math.round(x)) % 4];
    solid(w, h, 2.4, x, h / 2 + 0.2, z, body, false, false);
    const floors = Math.max(3, Math.floor(h / 1.15));
    const cols = Math.max(2, Math.floor(w / 0.85));
    for (let level = 0; level < floors; level += 1) {
      for (let col = 0; col < cols; col += 1) {
        const mat = glowMat();
        const win = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.42), mat);
        win.position.set(
          x - w / 2 + ((col + 0.5) * w) / cols,
          1.1 + level * ((h - 1.2) / floors),
          z - 1.22,
        );
        scene.add(win);
        cityLights.push(mat);
      }
    }
  }
  [
    [-16, 16, 4.8],
    [-10, 22, 4.2],
    [-4.5, 13, 5.2],
    [1.2, 19, 4.4],
    [7, 24, 4],
    [12.5, 15, 5],
  ].forEach(([x, h, w]) => apartment(x, h, w));

  const stone = std(0xfaf3f5, 0.92);
  const blush = std(0xf8e8ed, 0.92);
  const linen = std(0xfff9fa, 0.94);
  const brick = std(0xd7b093, 0.88);
  const slate = std(0x8d7360, 0.8);
  const bodies = [stone, blush, linen, brick, mats.lobby];
  const roofs = [slate, mats.woodDeep, mats.wine, mats.gold];

  function block(x, z, yaw, w, h, body, roofColor) {
    const group = new THREE.Group();
    group.position.set(x, 0, z);
    group.rotation.y = yaw;
    const depth = Math.min(w * 0.62, 7);
    part(group, w + 0.15, 0.4, depth + 0.2, 0, 0.2, 0, mats.stone);
    part(group, w, h, depth, 0, 0.4 + h / 2, 0, body);
    part(group, w + 0.35, 0.14, depth + 0.28, 0, 0.4 + h + 0.08, 0, mats.gold);
    part(group, w - 0.25, 0.85, depth - 0.35, 0, 0.4 + h + 0.62, 0, roofColor);
    const floors = Math.max(2, Math.min(6, Math.round(h / 1.7)));
    const cols = Math.max(2, Math.round(w / 1.45));
    for (let level = 0; level < floors; level += 1) {
      for (let col = 0; col < cols; col += 1) {
        if (level === 0 && col === Math.floor(cols / 2)) continue;
        const win = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 0.68), mats.glass);
        win.position.set(-w / 2 + ((col + 0.5) * w) / cols, 1.15 + level * ((h - 0.6) / floors), depth / 2 + 0.02);
        group.add(win);
      }
    }
    const door = new THREE.Mesh(new THREE.PlaneGeometry(0.62, 1.15), mats.woodDeep);
    door.position.set(0, 0.95, depth / 2 + 0.03);
    const awning = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.05, 0.55), mats.wine);
    awning.position.set(0, 1.7, depth / 2 + 0.22);
    group.add(door, awning);
    scene.add(group);
  }

  function tower(x, z, yaw, w, h) {
    block(x, z, yaw, w, h * 0.72, linen, slate);
    const cap = new THREE.Mesh(new THREE.BoxGeometry(w * 0.72, h * 0.28, w * 0.5), blush);
    cap.position.set(x, h * 0.72 + h * 0.14 + 0.5, z);
    cap.castShadow = true;
    scene.add(cap);
  }

  [
    [-25, -10, Math.PI / 2, 7.2, 8.5, stone, slate],
    [-28, -2, Math.PI / 2, 5.4, 6.5, blush, mats.woodDeep],
    [-24, 7, Math.PI / 2, 6.2, 10, linen, slate],
    [-31, -16, Math.PI / 2, 4.8, 7, brick, mats.wine],
    [25, -9, -Math.PI / 2, 6.4, 9, linen, slate],
    [29, 1, -Math.PI / 2, 5.2, 7.2, blush, mats.woodDeep],
    [24.5, 9, -Math.PI / 2, 7, 11, stone, slate],
    [32, -15, -Math.PI / 2, 4.6, 6.4, brick, mats.wine],
    [-6, -31, 0, 8, 7.5, linen, slate],
    [5, -34, 0, 6, 9.5, blush, mats.woodDeep],
    [15, -30, 0, 5.2, 6.2, stone, slate],
  ].forEach(([x, z, yaw, w, h, body, roofColor]) => block(x, z, yaw, w, h, body, roofColor));
  tower(-40, 2, Math.PI / 2, 5.2, 24);
  tower(38, -4, -Math.PI / 2, 4.6, 20);
  tree(-22, -6, 1.3, true);
  tree(-22.5, 3, 1.15, false);
  tree(22, -4, 1.25, true);
  tree(22.5, 5, 1.2, false);
  tree(-2, -27.5, 1.35, true);
  tree(9, -27.2, 1.2, false);

  // Quiet garden, in the spirit of a slow temple walk.
  disc(0, -16.7, 3.25, mats.stone, 0.03);
  const pond = disc(0, -16.7, 2.55, mats.water, 0.055);
  pond.material = new THREE.MeshStandardMaterial({
    color: 0x7eb8b2,
    roughness: 0.22,
    metalness: 0.04,
    transparent: true,
    opacity: 0.92,
  });
  circles.push({ x: 0, z: -16.7, r: 2.28 });
  for (const [x, z, s] of [
    [0.55, -16.15, 0.42],
    [-0.75, -17.05, 0.5],
    [0.25, -17.35, 0.34],
    [-0.35, -16.0, 0.3],
  ]) {
    const pad = new THREE.Mesh(new THREE.CircleGeometry(s, 18), mats.lily);
    pad.rotation.x = -Math.PI / 2;
    pad.position.set(x, 0.075, z);
    scene.add(pad);
    const flower = new THREE.Mesh(new THREE.SphereGeometry(0.08, 10, 8), mats.petal);
    flower.position.set(x + 0.05, 0.12, z);
    scene.add(flower);
  }
  ripple(0.2, -16.5, 0.2);
  ripple(-0.4, -17.0, 0.55);
  for (let i = 0; i < 8; i += 1) {
    solid(2.55, 0.08, 0.26, 0, 0.07, -11.85 - i * 0.4, mats.wood, false, true);
  }
  const gate = new THREE.Mesh(new THREE.TorusGeometry(1.28, 0.08, 10, 40), mats.wood);
  gate.position.set(0, 1.28, -9.4);
  gate.castShadow = true;
  scene.add(gate);
  circles.push({ x: -1.28, z: -9.4, r: 0.2 }, { x: 1.28, z: -9.4, r: 0.2 });
  for (let i = 0; i < 6; i += 1) {
    const stone = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.05, 0.46), mats.stone);
    stone.position.set(i % 2 === 0 ? -0.16 : 0.18, 0.045, -8.85 - i * 0.42);
    stone.rotation.y = i % 2 === 0 ? 0.08 : -0.1;
    stone.receiveShadow = true;
    scene.add(stone);
  }
  lantern(-3.35, -14.5);
  lantern(3.55, -18.6);
  bench(4.35, -13.55, Math.PI);
  bench(-4.55, -14.7, Math.PI);
  for (const [x, z, color] of [
    [2.25, -13.15, mats.sage],
    [-2.15, -12.85, mats.rose],
    [1.5, -12.15, mats.butter],
  ]) {
    const cushion = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.4, 0.11, 18), color);
    cushion.position.set(x, 0.07, z);
    cushion.receiveShadow = true;
    scene.add(cushion);
  }
  for (let i = 0; i < 5; i += 1) {
    const angle = Math.PI * 0.55 + i * 0.35;
    const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(0.18 + (i % 3) * 0.05, 0), mats.stone);
    rock.position.set(Math.cos(angle) * 3.05, 0.1, -16.7 + Math.sin(angle) * 2.4);
    rock.scale.y = 0.7;
    rock.castShadow = true;
    scene.add(rock);
  }
  tree(-6.4, -11.2, 1.55, false);
  tree(6.3, -12.4, 1.75, true);
  tree(-5.2, -20.2, 1.85, true);
  tree(5.6, -20.6, 1.55, false);
  tree(3.4, -21.8, 1.35, true);
  plant(-2.5, -10.15, 0.7);
  plant(2.55, -10.25, 0.65, true);

  function layPicnic(x, z, yaw, rose) {
    const picnic = new THREE.Group();
    picnic.position.set(x, 0, z);
    picnic.rotation.y = yaw;
    const cloth = document.createElement("canvas");
    cloth.width = 256;
    cloth.height = 192;
    const cg = cloth.getContext("2d");
    cg.fillStyle = rose ? "#f6ead4" : "#e7f0df";
    cg.fillRect(0, 0, 256, 192);
    for (let stripe = 0; stripe < 256; stripe += 22) {
      cg.fillStyle = stripe % 44 === 0 ? (rose ? "#e7b7c6" : "#c5d3b4") : (rose ? "#f3d7b0" : "#f7f3ea");
      cg.fillRect(stripe, 0, 7, 192);
    }
    cg.strokeStyle = rose ? "#c9a36a" : "#8ea37a";
    cg.lineWidth = 10;
    cg.strokeRect(6, 6, 244, 180);
    const clothTex = new THREE.CanvasTexture(cloth);
    clothTex.colorSpace = THREE.SRGBColorSpace;
    clothTex.anisotropy = anisotropy;
    const mat = new THREE.Mesh(
      new THREE.BoxGeometry(2.7, 0.025, 1.75),
      new THREE.MeshStandardMaterial({ map: clothTex, roughness: 0.86, color: 0xfff8ef }),
    );
    mat.position.y = 0.03;
    mat.receiveShadow = true;
    picnic.add(mat);
    const side = rose ? -1 : 1;
    const wicker = std(0xc4a06a, 0.72);
    const basket = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.24, 0.3), wicker);
    basket.position.set(-0.82 * side, 0.16, 0.28);
    const lid = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.04, 0.32), std(0xd7b56a, 0.6));
    lid.position.set(-0.82 * side, 0.29, 0.28);
    const handle = new THREE.Mesh(new THREE.TorusGeometry(0.13, 0.015, 8, 18, Math.PI), wicker);
    handle.position.set(-0.82 * side, 0.34, 0.28);
    handle.rotation.z = Math.PI;
    picnic.add(basket, lid, handle);
    const bottle = new THREE.Mesh(
      new THREE.CylinderGeometry(0.045, 0.05, 0.26, 12),
      std(rose ? 0xf4c9d4 : 0xd5e4c4, 0.35),
    );
    bottle.position.set(-0.48 * side, 0.17, 0.42);
    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.028, 0.08, 10), std(0xf7e7ea, 0.3));
    neck.position.set(-0.48 * side, 0.33, 0.42);
    picnic.add(bottle, neck);
    [[-0.22, 0.46], [-0.02, 0.38]].forEach(([cx, cz]) => {
      const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.038, 0.07, 12), std(0xfffbf6, 0.32));
      cup.position.set(cx * side, 0.075, cz);
      picnic.add(cup);
    });
    const plate = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.18, 0.02, 20), std(0xfffbf7, 0.3));
    plate.position.set(0.35 * side, 0.05, -0.15);
    const apple = new THREE.Mesh(new THREE.SphereGeometry(0.055, 12, 10), std(rose ? 0xc4455c : 0xe89a3c, 0.42));
    apple.position.set(0.28 * side, 0.1, -0.1);
    const orange = new THREE.Mesh(new THREE.SphereGeometry(0.05, 12, 10), std(rose ? 0xe89a3c : 0xc4455c, 0.48));
    orange.position.set(0.4 * side, 0.095, -0.22);
    const grapes = std(rose ? 0x6d4a86 : 0x6f9a62, 0.4);
    [[0.46, -0.08], [0.5, -0.16], [0.42, -0.18]].forEach(([gx, gz]) => {
      const grape = new THREE.Mesh(new THREE.SphereGeometry(0.028, 8, 6), grapes);
      grape.position.set(gx * side, 0.08, gz);
      picnic.add(grape);
    });
    picnic.add(plate, apple, orange);
    const bread = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.05, 0.12), std(0xf0d2a8, 0.55));
    bread.position.set(0.72 * side, 0.07, 0.32);
    const filling = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.012, 0.1), std(rose ? 0xc45d73 : 0x7ea36a, 0.5));
    filling.position.set(0.72 * side, 0.1, 0.32);
    const top = bread.clone();
    top.position.y = 0.125;
    picnic.add(bread, filling, top);
    const napkin = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.015, 0.22), std(rose ? 0xf6dde4 : 0xe4f0dc, 0.7));
    napkin.position.set(0.15 * side, 0.045, 0.42);
    napkin.rotation.y = 0.4;
    picnic.add(napkin);
    picnic.traverse((mesh) => {
      if (mesh.isMesh) mesh.castShadow = true;
    });
    mat.castShadow = false;
    scene.add(picnic);
    circles.push({ x: x - 0.75 * side, z: z + 0.2, r: 0.28 });
  }
  layPicnic(6.45, -18.05, -0.28, true);
  layPicnic(-6.7, -17.55, 0.32, false);
  register(0.1, -17.8, 8.2, {
    title: "Picnic lawn",
    ko: "피크닉 잔디",
    body: "Two mats on the grass, one on each side. A basket, fruit, sandwiches, and tea sit on each.",
    bodyKo: "잔디 양쪽에 돗자리가 있어요. 바구니, 과일, 샌드위치, 차가 올려져 있어요.",
  });

  wallNote(
    3.2,
    1.55,
    -8.28,
    Math.PI,
    "Quiet garden",
    "고요한 정원",
    ["A pond, a deck, cushions.", "A slow minute after class."],
    ["연못, 데크, 방석.", "수업 뒤의 잠시."],
    "A still pond and a wooden deck, in the spirit of a slow temple walk. Sit, then wander back.",
    "잔잔한 연못과 나무 데크. 느린 산책의 기분으로 앉았다가, 다시 걸어가 보세요.",
  );

  const allowed = [
    { x0: -17.2, x1: 17.2, z0: -7.9, z1: 13.58 },
    { x0: -17.7, x1: 17.7, z0: -23.45, z1: -7.72 },
    { x0: -20.6, x1: -17.15, z0: -11.5, z1: 15.7 },
    { x0: 17.15, x1: 20.6, z0: -11.5, z1: 15.7 },
    { x0: -20.6, x1: -14.2, z0: -11.5, z1: -7.7 },
    { x0: 14.2, x1: 20.6, z0: -11.5, z1: -7.7 },
    { x0: -20.6, x1: 20.6, z0: 13.35, z1: 15.7 },
  ];

  function blocked(x, z, radius = 0.29) {
    const inside = allowed.some((box) => x >= box.x0 && x <= box.x1 && z >= box.z0 && z <= box.z1);
    if (!inside) return true;
    for (const box of aabbs) {
      const cx = Math.max(box.minX, Math.min(x, box.maxX));
      const cz = Math.max(box.minZ, Math.min(z, box.maxZ));
      const dx = x - cx;
      const dz = z - cz;
      if (dx * dx + dz * dz < radius * radius) return true;
    }
    for (const circle of circles) {
      const dx = x - circle.x;
      const dz = z - circle.z;
      const reach = radius + circle.r;
      if (dx * dx + dz * dz < reach * reach) return true;
    }
    return false;
  }

  const places = [
    { en: "Quiet garden", ko: "고요한 정원", x0: -18, x1: 18, z0: -24, z1: -8.02 },
    { en: "English classroom", ko: "영어 교실", x0: 6.05, x1: 17.6, z0: -8.1, z1: 5.95 },
    { en: "AI study lounge", ko: "AI 공부 라운지", x0: -17.6, x1: -6.05, z0: -8.1, z1: 5.95 },
    { en: "Club room", ko: "4-5인 동아리실", x0: 6.15, x1: 10.45, z0: 6.15, z1: 10.25 },
    { en: "Club room", ko: "4-5인 동아리실", x0: 12.5, x1: 17.15, z0: 6.15, z1: 10.25 },
    { en: "Sea project deck", ko: "바다 작업 데크", x0: 6.05, x1: 17.3, z0: 10.45, z1: 13.9 },
    { en: "Build your AI office", ko: "AI 사무실 만들기", x0: -17.6, x1: -6.05, z0: 6.05, z1: 14.05 },
    { en: "Sea terrace", ko: "바다 테라스", x0: -6.05, x1: 6.05, z0: 6.05, z1: 15.8 },
    { en: "Outside path", ko: "바깥 산책로", x0: -20.8, x1: -17.15, z0: -12, z1: 15.9 },
    { en: "Outside path", ko: "바깥 산책로", x0: 17.15, x1: 20.8, z0: -12, z1: 15.9 },
    { en: "Lobby", ko: "로비", x0: -6.05, x1: 6.05, z0: -8.1, z1: 6.05 },
  ];

  function placeAt(x, z) {
    return places.find((place) => x >= place.x0 && x <= place.x1 && z >= place.z0 && z <= place.z1)
      || { en: "Campus", ko: "캠퍼스" };
  }

  const offices = [
    { id: "club-garden", en: "Club room", ko: "동아리실", x0: 6.15, x1: 10.45, z0: 6.15, z1: 10.25 },
    { id: "club-sea", en: "Sea club room", ko: "바다 동아리실", x0: 12.5, x1: 17.15, z0: 6.15, z1: 10.25 },
    { id: "ai-office", en: "AI office", ko: "AI 사무실", x0: -17.6, x1: -6.05, z0: 6.05, z1: 14.05 },
  ];

  const probes = [
    ["spawn", 0, 4.55, false],
    ["under sign", 0, 0.4, false],
    ["garden door", 0, -8, false],
    ["north wall", 4.5, -8, true],
    ["east wall", 17.5, 0, true],
    ["class door", 6, 0, false],
    ["class open", 7.5, 3.3, false],
    ["desk", 9.0, -4.4, true],
    ["aisle", 10.35, -4.4, false],
    ["lounge", -12.2, 0.3, false],
    ["lounge door", -6, 0, false],
    ["terrace", 0, 9.2, false],
    ["rent door", 6, 8.15, false],
    ["rent room", 6.7, 8.4, false],
    ["divider", 10.6, 8.3, true],
    ["project deck", 6.7, 11.4, false],
    ["ai office", -16.2, 9.3, false],
    ["ai door", -6, 10.1, false],
    ["rail", 0, 14, false],
    ["river", 0, 16.4, true],
    ["side path", 19.25, 1.2, false],
    ["west path", -19.25, 8.4, false],
    ["path shore", 8.5, 14.8, false],
    ["pond", 0, -16.7, true],
    ["garden path", 0, -12.3, false],
    ["moon gate", 0, -9.4, false],
    ["corner", 17.75, -7.6, true],
    ["void", 28, 0, true],
  ].map(([name, x, z, want]) => ({ name, x, z, want }));

  const people = [];
  function paintedFace() {
    const c = document.createElement("canvas");
    c.width = 256;
    c.height = 256;
    const g = c.getContext("2d");
    const blushAt = (x) => {
      const grd = g.createRadialGradient(x, 156, 2, x, 156, 30);
      grd.addColorStop(0, "rgba(232, 148, 156, 0.7)");
      grd.addColorStop(1, "rgba(232, 148, 156, 0)");
      g.fillStyle = grd;
      g.beginPath();
      g.arc(x, 156, 30, 0, Math.PI * 2);
      g.fill();
    };
    blushAt(74);
    blushAt(182);
    g.fillStyle = "#3a2a24";
    const eye = (x) => {
      g.beginPath();
      g.ellipse(x, 112, 16, 20, 0, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = "#fffaf6";
      g.beginPath();
      g.arc(x + 5, 104, 5, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = "#3a2a24";
    };
    eye(96);
    eye(160);
    g.strokeStyle = "#c96b78";
    g.lineWidth = 8;
    g.lineCap = "round";
    g.beginPath();
    g.arc(128, 158, 18, 0.18 * Math.PI, 0.82 * Math.PI);
    g.stroke();
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.needsUpdate = true;
    return new THREE.MeshBasicMaterial({
      map: tex,
      transparent: true,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -2,
      polygonOffsetUnits: -2,
    });
  }
  const faceMat = paintedFace();
  function addPerson(name, ko, look, path, lines) {
    const group = new THREE.Group();
    const skin = std(0xf6c8ae, 0.62);
    const legL = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.06, 0.28, 8), look.legs);
    legL.position.set(-0.07, 0.16, 0);
    const legR = legL.clone();
    legR.position.x = 0.07;
    const shoeL = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.05, 0.14), std(0x5c463c, 0.6));
    shoeL.position.set(-0.07, 0.03, 0.02);
    const shoeR = shoeL.clone();
    shoeR.position.x = 0.07;
    const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.18, 0.36, 12), look.shirt);
    torso.position.y = 0.48;
    const armL = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.04, 0.26, 8), look.shirt);
    armL.position.set(-0.2, 0.5, 0);
    armL.rotation.z = 0.35;
    const armR = armL.clone();
    armR.position.x = 0.2;
    armR.rotation.z = -0.35;
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.16, 18, 14), skin);
    head.position.y = 0.86;
    const hair = new THREE.Mesh(
      new THREE.SphereGeometry(0.17, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.42),
      look.hair,
    );
    hair.position.y = 0.92;
    const fringe = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.04, 0.07), look.hair);
    fringe.position.set(0, 0.99, -0.09);
    const face = new THREE.Mesh(new THREE.PlaneGeometry(0.18, 0.18), faceMat);
    face.position.set(0, 0.83, -0.162);
    face.rotation.y = Math.PI;
    face.castShadow = false;
    const parts = [legL, legR, shoeL, shoeR, torso, armL, armR, head, hair, fringe, face];
    if (look.long) {
      const lockL = new THREE.Mesh(new THREE.CapsuleGeometry(0.032, 0.16, 3, 8), look.hair);
      lockL.position.set(-0.13, 0.74, 0.01);
      const lockR = lockL.clone();
      lockR.position.x = 0.13;
      parts.push(lockL, lockR);
    }
    parts.forEach((mesh) => {
      mesh.castShadow = mesh !== face;
      group.add(mesh);
    });
    group.scale.setScalar(1.5);
    group.position.set(path[0][0], 0, path[0][1]);
    scene.add(group);
    const circle = { x: path[0][0], z: path[0][1], r: 0.28 };
    circles.push(circle);
    people.push({ name, ko, path, chats: lines, group, circle, cursor: 0, topic: 0, bow: 0 });
  }
  addPerson("Hana", "하나", {
    shirt: mats.rose,
    legs: std(0xf6e7dc, 0.7),
    hair: std(0x5a382c, 0.7),
    long: true,
  }, [[-1.1, 2.4], [-1.1, -3.2], [2.2, -3.2], [2.2, 2.4]], [
    {
      en: "Good morning. The classroom board is free if you want to write.",
      ko: "좋은 아침이에요. 교실 칠판에 글을 적어도 돼요.",
      replies: [
        {
          youEn: "What are we practicing?",
          youKo: "오늘은 뭘 연습해요?",
          en: "Introductions. I'm ____. Nice to meet you.",
          ko: "자기소개예요. I'm ____. 만나서 반가워요.",
        },
        {
          youEn: "I might take a snack first.",
          youKo: "먼저 과자부터 집을까요.",
          en: "The pantry is behind you. I like the rose cookie.",
          ko: "팬트리는 뒤쪽이에요. 저는 장미 쿠키가 좋아요.",
        },
      ],
    },
    {
      en: "The lobby is the bright room. Where do you want to go?",
      ko: "로비가 가장 밝은 방이에요. 어디로 갈까요?",
      replies: [
        {
          youEn: "Which room should I try?",
          youKo: "어느 방부터 가볼까요?",
          en: "English class first. The AI lounge is the purple light, if you want to build something.",
          ko: "영어 교실부터요. 뭔가 만들고 싶으면 보라 불빛인 AI 라운지로 가요.",
        },
        {
          youEn: "Is anyone else around?",
          youKo: "다른 사람도 있어요?",
          en: "Jun walks the terrace. He likes the sea, and he will talk if you say hello.",
          ko: "준은 테라스를 걸어요. 바다를 좋아하고, 인사하면 이야기도 해요.",
        },
      ],
    },
  ]);
  addPerson("Jun", "준", {
    shirt: std(0xf7f1e4, 0.7),
    legs: std(0x6f8f9a, 0.7),
    hair: std(0x3a2a24, 0.7),
  }, [[-2.6, 8.6], [2.6, 8.6], [2.6, 11.4], [-2.6, 11.4]], [
    {
      en: "The water is quiet from here. Stay a minute if you like.",
      ko: "여기서 바다가 조용해요. 잠깐 있어도 좋아요.",
      replies: [
        {
          youEn: "Is the picnic still out?",
          youKo: "피크닉은 아직 있어요?",
          en: "Two mats on the garden lawn, one on each side of the pond. Basket, fruit, and tea.",
          ko: "정원 잔디, 연못 양옆에 돗자리가 있어요. 바구니, 과일, 차가 있어요.",
        },
        {
          youEn: "Can a group sit inside?",
          youKo: "안에도 같이 앉을 수 있어요?",
          en: "Two club rooms, four or five seats each. One is pink light, one is coral.",
          ko: "동아리실이 두 개예요. 넷에서 다섯 자리. 하나는 분홍 불, 하나는 코랄 불이에요.",
        },
      ],
    },
    {
      en: "The buttons up top change the hour. Night is my favorite.",
      ko: "위의 버튼이 시간을 바꿔요. 저는 밤이 제일 좋아요.",
      replies: [
        {
          youEn: "What does night look like?",
          youKo: "밤은 어떻게 보여요?",
          en: "The apartments across the water turn their lights on. The terrace lamp stays warm.",
          ko: "바다 건너 아파트에 불이 켜져요. 테라스 조명은 따뜻하게 남아요.",
        },
        {
          youEn: "Where is Hana?",
          youKo: "하나는 어디 있어요?",
          en: "She walks the lobby. Say hello and she will keep talking.",
          ko: "로비를 걸어요. 인사하면 이어서 이야기해 줘요.",
        },
      ],
    },
  ]);

  const moods = {
    sunrise: {
      sky: [[0, "#f6b7c0"], [0.35, "#f8c9a4"], [0.7, "#f3d7c4"], [1, "#e7b7a4"]],
      fog: "#f0c2b0",
      hemi: [0xffe6d2, 0xf3d8c8, 0.95],
      sunColor: 0xffb06a,
      sunLevel: 1.7,
      lamps: 0.85,
      sunPos: [-32, 5, 8],
      seaShallow: "#f2c4b0",
      seaDeep: "#6a5a88",
      lights: 0.25,
      cloud: 0.45,
    },
    morning: {
      sky: [[0, "#e7eef6"], [0.35, "#f7f8fa"], [0.7, "#fbfcfd"], [1, "#ffffff"]],
      fog: "#f7f8fa",
      hemi: [0xfffaf6, 0xf7f1ec, 1.75],
      sunColor: 0xfff3e6,
      sunLevel: 2.9,
      lamps: 0.75,
      sunPos: [-16, 28, -22],
      seaShallow: "#7ecfc4",
      seaDeep: "#163e66",
      lights: 0,
      cloud: 0.82,
    },
    afternoon: {
      sky: [[0, "#e4eef8"], [0.4, "#f5f7fa"], [0.75, "#fbfcfd"], [1, "#ffffff"]],
      fog: "#f7f8fa",
      hemi: [0xfffaf7, 0xf8f2ee, 1.85],
      sunColor: 0xfff4e8,
      sunLevel: 3.05,
      lamps: 0.65,
      sunPos: [12, 32, -8],
      seaShallow: "#8fd4cf",
      seaDeep: "#1a5278",
      lights: 0,
      cloud: 0.7,
    },
    sunset: {
      sky: [[0, "#5c3d6e"], [0.28, "#e07a62"], [0.55, "#f2b48a"], [1, "#f6d3b4"]],
      fog: "#e7b49a",
      hemi: [0xffa070, 0xd7a07a, 0.85],
      sunColor: 0xff6a2a,
      sunLevel: 2.15,
      lamps: 1.15,
      sunPos: [26, 4, 18],
      seaShallow: "#e89274",
      seaDeep: "#3a3a68",
      lights: 0.65,
      cloud: 0.35,
    },
    night: {
      sky: [[0, "#12182e"], [0.45, "#243456"], [0.78, "#3a3a58"], [1, "#2a2438"]],
      fog: "#1c2438",
      hemi: [0x6a5a78, 0x3a2418, 0.42],
      sunColor: 0xffb07a,
      sunLevel: 0.35,
      lamps: 1.45,
      sunPos: [8, 22, -30],
      seaShallow: "#1c3a55",
      seaDeep: "#0c1424",
      lights: 1,
      cloud: 0.12,
    },
  };

  function setTime(name) {
    const mood = moods[name] || moods.morning;
    paintSky(mood.sky);
    scene.fog.color.set(mood.fog);
    scene.background.set(mood.fog);
    hemi.color.set(mood.hemi[0]);
    hemi.groundColor.set(mood.hemi[1]);
    hemi.intensity = mood.hemi[2];
    sun.color.set(mood.sunColor);
    sun.intensity = mood.sunLevel;
    sun.position.set(mood.sunPos[0], mood.sunPos[1], mood.sunPos[2]);
    sunMesh.material.color.set(mood.sunColor);
    sunMesh.position.set(mood.sunPos[0] * 1.4, Math.max(8, mood.sunPos[1]), mood.sunPos[2] * 1.2);
    paintSea(mood.seaShallow, mood.seaDeep);
    cloudMat.opacity = mood.cloud;
    const lampLevel = mood.lamps == null ? 1 : mood.lamps;
    lamps.forEach((light) => {
      light.intensity = light.userData.base * lampLevel;
    });
    cityLights.forEach((mat) => {
      mat.emissiveIntensity = mood.lights;
    });
    return name;
  }
  setTime("morning");

  const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.05, 0.12, 10), mats.gold);
  cup.position.set(-11.05, FLOOR + 0.92, 2.55);
  cup.castShadow = true;
  const bloom = new THREE.Mesh(new THREE.SphereGeometry(0.1, 10, 8), mats.blossom);
  bloom.position.set(1.75, 0.32, -11.1);
  bloom.castShadow = true;
  scene.add(cup, bloom);
  snacks.push(
    { en: "Tea cup", ko: "찻잔", x: -11.05, z: 2.55, mesh: cup, taken: false },
    { en: "Garden bloom", ko: "정원 꽃", x: 1.75, z: -11.1, mesh: bloom, taken: false },
  );

  function tick(time) {
    if (ripples.waves) {
      const { pos, base } = ripples.waves;
      for (let i = 0; i < pos.count; i += 1) {
        const x = base[i * 3];
        const z = base[i * 3 + 2];
        pos.setY(i, Math.sin(x * 0.32 + time * 1.05) * 0.03 + Math.sin(z * 0.24 + time * 0.75) * 0.04);
      }
      pos.needsUpdate = true;
    }
    for (const ripple of ripples) {
      const u = (time * 0.12 + ripple.phase) % 1;
      const scale = 0.35 + u * 1.7;
      ripple.mesh.scale.set(scale, scale, scale);
      ripple.mat.opacity = 0.28 * (1 - u);
    }
    for (const cloud of clouds) {
      cloud.mesh.position.x = cloud.base + Math.sin(time * 0.05 + cloud.phase) * 1.4;
    }
    const previous = tick.last || time;
    const dt = Math.min(0.05, Math.max(0, time - previous));
    tick.last = time;
    for (const person of people) {
      const target = person.path[person.cursor];
      const dx = target[0] - person.circle.x;
      const dz = target[1] - person.circle.z;
      const dist = Math.hypot(dx, dz) || 0.0001;
      const step = Math.min(dist, 1.15 * dt);
      person.circle.x += (dx / dist) * step;
      person.circle.z += (dz / dist) * step;
      person.group.position.set(person.circle.x, Math.abs(Math.sin(time * 7)) * 0.025, person.circle.z);
      if (dist > 0.05) person.group.rotation.y = Math.atan2(-dx, -dz);
      if (person.bow > 0) {
        person.bow -= dt;
        person.group.rotation.x = Math.sin(person.bow * 8) * 0.12;
      } else {
        person.group.rotation.x = 0;
      }
      if (dist < 0.08) person.cursor = (person.cursor + 1) % person.path.length;
    }
  }

  function paintMeet(id, code) {
    if (meetPaints[id]) meetPaints[id](code || "");
  }

  hangArt(12.25, 1.95, -7.66, 0, 1.16, "starry.jpg", 960 / 760, "Van Gogh · The Starry Night");
  hangArt(-12.25, 1.9, -7.66, 0, 1.12, "almond.jpg", 960 / 758, "Van Gogh · Almond Blossom");
  hangArt(3.85, 1.95, -7.64, 0, 1.55, "sunflowers.jpg", 960 / 1221, "Van Gogh · Sunflowers");
  hangArt(-5.76, 1.95, -4.15, Math.PI / 2, 1.78, "cafe.jpg", 960 / 1204, "Van Gogh · Café Terrace");
  hangArt(-17.18, 1.78, 12.72, Math.PI / 2, 1.12, "bedroom.jpg", 960 / 762, "Van Gogh · The Bedroom");
  hangArt(7.45, 1.6, 10.06, Math.PI, 0.9, "irises.jpg", 960 / 734, "Van Gogh · Irises");
  hangArt(13.16, 3.25, 10.06, Math.PI, 0.78, "wheat.jpg", 960 / 752, "Van Gogh · Wheat Field");
  hangArt(-17.18, 1.72, 3.4, Math.PI / 2, 1.2, "cafe.jpg", 960 / 1204, "Van Gogh · Café Terrace");

  return { scene, blocked, signs, snacks, boards, people, offices, setTime, placeAt, probes, tick, paintMeet };
}
