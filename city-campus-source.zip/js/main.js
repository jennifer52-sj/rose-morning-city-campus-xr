import * as THREE from "three";
import { VRButton } from "../vendor/three/VRButton.js";
import { createCampus } from "./campus.js?v=25";
import { createPlayer } from "./player.js";

const params = new URLSearchParams(location.search);
const shot = params.get("shot");

const SHOTS = {
  lobby: { pos: [2.35, 1.5, 4.55], look: [0.05, 1.72, -1.4] },
  classroom: { pos: [7.3, 1.68, 4.55], look: [13.8, 1.2, -0.5] },
  lounge: { pos: [-7.5, 1.58, 3.1], look: [-15.2, 1.55, -0.6] },
  garden: { pos: [0.2, 1.62, -10.4], look: [0.15, 0.9, -16.6] },
  office: { pos: [13.4, 1.55, 9.15], look: [16.7, 1.55, 7.4] },
  terrace: { pos: [0.4, 1.72, 10.6], look: [1.2, 0.35, 32] },
  hana: { pos: [0.4, 1.05, 4.1], look: [-1.05, 0.55, 2.35] },
  west: { pos: [-12, 1.8, -15], look: [-30, 5, -8] },
  northtown: { pos: [0.4, 1.9, -16], look: [4, 6, -36] },
  aidoor: { pos: [-2.2, 1.55, 10.1], look: [-6.1, 1.7, 10.4] },
};

async function loadFonts() {
  const jobs = [
    document.fonts.load("700 64px Fraunces"),
    document.fonts.load("600 40px Nunito"),
    document.fonts.load("600 40px 'Noto Sans KR'"),
    document.fonts.load("400 40px 'Noto Sans KR'"),
  ];
  await Promise.race([
    Promise.all(jobs).then(() => document.fonts.ready),
    new Promise((resolve) => setTimeout(resolve, 4500)),
  ]);
}

function softenVR(button) {
  const fix = () => {
    const text = button.textContent || "";
    if (/NOT SUPPORTED|NOT AVAILABLE|WEBXR/i.test(text)) {
      button.textContent = "VR on Quest";
      button.title = "A Quest browser shows Enter VR here. This campus also works without a headset.";
    }
  };
  const observer = new MutationObserver(fix);
  observer.observe(button, { childList: true, characterData: true, subtree: true });
  setTimeout(fix, 500);
}

function bindChrome(player) {
  const hintEn = document.getElementById("hint-en");
  const hintKo = document.getElementById("hint-ko");
  const guide = document.getElementById("guide");
  const guideBtn = document.getElementById("guide-btn");
  const coarse = window.matchMedia("(pointer: coarse)").matches;
  if (coarse) document.body.classList.add("touch");
  window.addEventListener(
    "touchstart",
    () => document.body.classList.add("touch"),
    { once: true, passive: true },
  );

  const renderHint = () => {
    const touch = document.body.classList.contains("touch");
    const locked = document.pointerLockElement !== null;
    if (touch) {
      hintEn.textContent = "Joystick walks · drag to look · buttons appear when you are close";
      hintKo.textContent = "조이스틱으로 걷고, 드래그로 둘러봐요. 가까이 가면 인사·집기 버튼이 나와요.";
    } else if (locked) {
      hintEn.textContent = "WASD walks · G says hello · F picks up · Esc frees the mouse";
      hintKo.textContent = "WASD로 걸어요. G는 인사, F는 집기, Esc는 마우스를 놓아요.";
    } else {
      hintEn.textContent = "WASD walks · click a person to say hello · click an object to pick it up";
      hintKo.textContent = "WASD로 걸어요. 사람을 클릭하면 인사, 물건을 클릭하면 집어요. 빈 곳을 클릭하면 둘러봐요.";
    }
  };
  renderHint();
  document.addEventListener("pointerlockchange", renderHint);

  const setGuide = (open) => {
    guide.hidden = !open;
    guideBtn.setAttribute("aria-expanded", open ? "true" : "false");
  };
  guideBtn.addEventListener("click", () => setGuide(guide.hidden));
  document.getElementById("guide-close").addEventListener("click", () => setGuide(false));
  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape") setGuide(false);
  });
  guide.addEventListener("click", (e) => {
    if (e.target === guide) setGuide(false);
  });

  return { renderHint };
}

async function boot() {
  const status = document.getElementById("status");
  await loadFonts();
  if (status) status.textContent = "Setting the tables…";

  const renderer = new THREE.WebGLRenderer({
    antialias: true,
    alpha: false,
    preserveDrawingBuffer: Boolean(shot),
  });
  renderer.setPixelRatio(shot ? 1 : Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.NeutralToneMapping;
  renderer.toneMappingExposure = Number(params.get("exposure") || 1.02);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.xr.enabled = true;
  const canvas = renderer.domElement;
  canvas.addEventListener("contextmenu", (event) => event.preventDefault());
  document.getElementById("stage").appendChild(canvas);

  const camera = new THREE.PerspectiveCamera(
    68,
    window.innerWidth / window.innerHeight,
    0.08,
    180,
  );
  const campus = createCampus(renderer.capabilities.getMaxAnisotropy());
  let clickWorld = () => false;
  const player = createPlayer({
    camera,
    canvas,
    blocked: campus.blocked,
    joystick: document.getElementById("joystick"),
    knob: document.getElementById("knob"),
    onPress: (event) => clickWorld(event),
  });
  campus.scene.add(player.rig);

  const vrButton = VRButton.createButton(renderer);
  vrButton.id = "vr-button";
  document.body.appendChild(vrButton);
  softenVR(vrButton);

  renderer.xr.addEventListener("sessionstart", () => {
    camera.position.set(0, 0, 0);
    camera.rotation.set(0, 0, 0);
  });
  renderer.xr.addEventListener("sessionend", () => {
    camera.position.set(0, player.eye, 0);
    camera.rotation.set(player.state.pitch, 0, 0);
  });

  if (!shot) bindChrome(player);

  if (shot && SHOTS[shot]) {
    camera.fov = 74;
    camera.updateProjectionMatrix();
    const view = SHOTS[shot];
    player.state.freeze = true;
    player.rig.position.set(0, 0, 0);
    player.rig.rotation.set(0, 0, 0);
    camera.position.set(view.pos[0], view.pos[1], view.pos[2]);
    camera.lookAt(view.look[0], view.look[1], view.look[2]);
    player.rig.updateMatrixWorld(true);
  } else {
    player.place(0, 4.55, 0);
  }

  window.addEventListener("resize", () => {
    if (renderer.xr.isPresenting) return;
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  const near = document.getElementById("near");
  const nearTitle = document.getElementById("near-title");
  const nearKo = document.getElementById("near-ko");
  const nearBody = document.getElementById("near-body");
  const placeEn = document.getElementById("place-en");
  const placeKo = document.getElementById("place-ko");
  let nearId = "";
  let placeName = "";
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const bagEl = document.getElementById("bag");
  const bagCount = document.getElementById("bag-count");
  const bagLast = document.getElementById("bag-last");
  const pickup = document.getElementById("pickup");
  const held = [];
  let pickupWasDown = false;

  const nearestSnack = (x, z) => {
    let best = null;
    let bestD = 1.55;
    for (const snack of campus.snacks) {
      if (snack.taken) continue;
      const dist = Math.hypot(x - snack.x, z - snack.z);
      if (dist < bestD) {
        best = snack;
        bestD = dist;
      }
    }
    return best;
  };

  const takeSnack = (snack) => {
    if (!snack || snack.taken) return;
    snack.taken = true;
    snack.mesh.visible = false;
    held.push(snack);
    bagEl.hidden = false;
    bagCount.textContent = String(held.length);
    bagLast.textContent = `${snack.en} · ${snack.ko}`;
  };

  const writer = document.getElementById("writer");
  const writerText = document.getElementById("writer-text");
  let ink = "#2E2420";
  writer.querySelectorAll("[data-ink]").forEach((button) => {
    button.addEventListener("click", () => {
      ink = button.dataset.ink;
      writer.querySelectorAll("[data-ink]").forEach((swatch) => swatch.classList.remove("on"));
      button.classList.add("on");
    });
  });
  writer.addEventListener("submit", (event) => {
    event.preventDefault();
    const board = nearestBoard(player.state.x, player.state.z);
    if (board && board.add(writerText.value, ink)) writerText.value = "";
  });

  const nearestBoard = (x, z) => {
    let best = null;
    let bestD = Infinity;
    for (const board of campus.boards) {
      const dist = Math.hypot(x - board.x, z - board.z);
      if (dist < board.r && dist < bestD) {
        best = board;
        bestD = dist;
      }
    }
    return best;
  };

  window.addEventListener("keydown", (event) => {
    const tag = event.target && event.target.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA") return;
    const key = event.key.toLowerCase();
    if (event.repeat) return;
    if (key === "g") greet(nearestPerson(player.state.x, player.state.z));
    if (key === "1" || key === "2") window.__chooseTalk(Number(key) - 1);
    if (key !== "f" && key !== "e") return;
    takeSnack(nearestSnack(player.state.x, player.state.z));
  });
  pickup.addEventListener("click", () => {
    takeSnack(nearestSnack(player.state.x, player.state.z));
  });
  const talk = document.getElementById("talk");
  const talkName = document.getElementById("talk-name");
  const talkLine = document.getElementById("talk-line");
  const talkChoices = document.getElementById("talk-choices");
  const talkBtn = document.getElementById("talk-btn");
  const nearestPerson = (x, z) => {
    let best = null;
    let bestD = 1.8;
    for (const person of campus.people) {
      const dist = Math.hypot(x - person.circle.x, z - person.circle.z);
      if (dist < bestD) {
        best = person;
        bestD = dist;
      }
    }
    return best;
  };
  const promptHello = (person) => {
    talkName.textContent = `${person.name} · ${person.ko}`;
    talkLine.textContent = "Say hello.\n인사해 보세요.";
    talkChoices.replaceChildren();
    talkBtn.hidden = false;
    talkBtn.textContent = "Hello · 인사";
  };
  const showReplies = (person) => {
    const topic = person.chats[(person.topic - 1 + person.chats.length) % person.chats.length];
    talkChoices.replaceChildren();
    topic.replies.forEach((reply, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.innerHTML = `${index + 1}. ${reply.youEn}<span>${reply.youKo}</span>`;
      button.addEventListener("click", () => answerTalk(person, reply));
      talkChoices.append(button);
    });
    talkBtn.hidden = true;
  };
  const greet = (person) => {
    if (!person) return;
    const topic = person.chats[person.topic % person.chats.length];
    person.topic += 1;
    person.bow = 0.6;
    talk.dataset.who = person.name;
    talkName.textContent = `${person.name} · ${person.ko}`;
    talkLine.textContent = `${topic.en}\n${topic.ko}`;
    showReplies(person);
  };
  const answerTalk = (person, reply) => {
    if (!person || !reply) return;
    person.bow = 0.45;
    talkLine.textContent = `You · 나\n${reply.youEn}\n${reply.youKo}\n\n${person.name} · ${person.ko}\n${reply.en}\n${reply.ko}`;
    talkChoices.replaceChildren();
    talkBtn.hidden = false;
    talkBtn.textContent = "Keep talking · 이어서";
  };
  talkBtn.addEventListener("click", () => {
    greet(nearestPerson(player.state.x, player.state.z));
  });
  window.__chooseTalk = (index) => {
    if (!talkChoices.children.length) return;
    const person = nearestPerson(player.state.x, player.state.z);
    const topic = person && person.chats[(person.topic - 1 + person.chats.length) % person.chats.length];
    if (topic && topic.replies[index]) answerTalk(person, topic.replies[index]);
  };
  const meet = document.getElementById("meet");
  const meetRoom = document.getElementById("meet-room");
  const meetStart = document.getElementById("meet-start");
  const meetTop = document.getElementById("meet-top");
  const meetCode = document.getElementById("meet-code");
  const meetNote = document.getElementById("meet-note");
  let meetId = "";
  const officeAt = (x, z) =>
    campus.offices.find((office) => x >= office.x0 && x <= office.x1 && z >= office.z0 && z <= office.z1) || null;
  const savedCode = (id) => {
    try {
      return localStorage.getItem(`rose-meet:${id}`) || "";
    } catch {
      return "";
    }
  };
  const rememberCode = (id, code) => {
    try {
      if (code) localStorage.setItem(`rose-meet:${id}`, code);
      else localStorage.removeItem(`rose-meet:${id}`);
    } catch {
      /* private mode */
    }
  };
  const meetUrl = (raw) => {
    const text = String(raw || "").trim();
    if (!text) return "";
    let code = text;
    try {
      const url = new URL(text);
      if (url.hostname !== "meet.google.com") return "";
      code = url.pathname.replace(/^\/+/, "").split("/")[0];
      if (code === "new") return "https://meet.google.com/new";
    } catch {
      code = text;
    }
    code = code.toLowerCase().replace(/\s+/g, "");
    if (!/^[a-z]{3}-[a-z]{4}-[a-z]{3}$/.test(code)) return "";
    return `https://meet.google.com/${code}`;
  };
  const refreshMeet = () => {
    const saved = meetId ? savedCode(meetId) : "";
    const url = saved ? `https://meet.google.com/${saved}` : "https://meet.google.com/new";
    const office = campus.offices.find((item) => item.id === meetId);
    meetStart.href = url;
    meetTop.href = url;
    meetStart.textContent = saved ? `Join ${saved} · 참가` : "Open Google Meet · 회의 열기";
    meetTop.textContent = office ? `Meet · ${office.ko}` : "Meet · 회의";
  };
  const openOfficeMeet = (office) => {
    if (office && meetId !== office.id) {
      meetId = office.id;
      meet.hidden = false;
      meetRoom.textContent = `${office.en} · ${office.ko}`;
      meetCode.value = savedCode(office.id);
      refreshMeet();
    }
    meetStart.click();
  };
  const syncMeet = (x, z) => {
    const office = officeAt(x, z);
    meet.hidden = !office;
    if (!office) {
      if (meetId) {
        meetId = "";
        refreshMeet();
      }
      return;
    }
    if (meetId === office.id) return;
    meetId = office.id;
    meetRoom.textContent = `${office.en} · ${office.ko}`;
    meetCode.value = savedCode(office.id);
    meetNote.textContent = "위 링크가 이 사무실의 Google Meet이에요. 코드를 적으면 같은 회의로 고정돼요.";
    refreshMeet();
  };
  campus.offices.forEach((office) => campus.paintMeet(office.id, savedCode(office.id)));
  document.getElementById("meet-new").addEventListener("click", () => {
    const office = officeAt(player.state.x, player.state.z);
    if (!office) return;
    rememberCode(office.id, "");
    meetCode.value = "";
    campus.paintMeet(office.id, "");
    refreshMeet();
    meetNote.textContent = "새 Google Meet이 열립니다. 코드를 아래에 적으면 이 사무실에 남아요.";
  });
  document.getElementById("meet-join").addEventListener("submit", (event) => {
    event.preventDefault();
    const office = officeAt(player.state.x, player.state.z);
    if (!office) return;
    const url = meetUrl(meetCode.value);
    if (!url || url.endsWith("/new")) {
      meetNote.textContent = "코드는 abc-defg-hij 이거나 meet.google.com 주소예요.";
      return;
    }
    rememberCode(office.id, url.split("/").pop());
    meetId = office.id;
    campus.paintMeet(office.id, url.split("/").pop());
    refreshMeet();
    meetNote.textContent = "이 사무실 링크를 그 회의로 바꿨어요. 같은 코드면 모두 한 방에 들어갑니다.";
    meetStart.click();
  });
  window.addEventListener("keydown", (event) => {
    const tag = event.target && event.target.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA") return;
    if (event.repeat || event.key.toLowerCase() !== "m") return;
    openOfficeMeet(officeAt(player.state.x, player.state.z));
  });

  const raycaster = new THREE.Raycaster();
  const pointer = new THREE.Vector2();
  const ownerOf = (object, list, key) => {
    let node = object;
    while (node) {
      const found = list.find((item) => item[key] === node);
      if (found) return found;
      node = node.parent;
    }
    return null;
  };
  clickWorld = (event) => {
    const rect = canvas.getBoundingClientRect();
    pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointer, camera);
    const hits = raycaster.intersectObjects(campus.scene.children, true);
    for (const hit of hits) {
      const person = ownerOf(hit.object, campus.people, "group");
      if (person) {
        greet(person);
        return true;
      }
      const snack = ownerOf(hit.object, campus.snacks, "mesh");
      if (snack && !snack.taken) {
        takeSnack(snack);
        return true;
      }
      let node = hit.object;
      while (node) {
        if (node.userData && node.userData.meet) {
          const office = campus.offices.find((item) => item.id === node.userData.meet);
          const code = office ? savedCode(office.id) : "";
          window.open(code ? `https://meet.google.com/${code}` : "https://meet.google.com/new", "_blank", "noopener,noreferrer");
          return true;
        }
        node = node.parent;
      }
    }
    return false;
  };
  document.getElementById("hours").addEventListener("click", (event) => {
    const button = event.target.closest("[data-hour]");
    if (!button) return;
    campus.setTime(button.dataset.hour);
    document.querySelectorAll("#hours button").forEach((item) => item.classList.remove("on"));
    button.classList.add("on");
  });

  const gamepadPickup = (session) => {
    if (!session) return false;
    for (const source of session.inputSources) {
      const buttons = source.gamepad && source.gamepad.buttons;
      if (!buttons) continue;
      if ((buttons[0] && buttons[0].pressed) || (buttons[4] && buttons[4].pressed)) return true;
    }
    return false;
  };

  const updateHud = (x, z) => {
    const place = campus.placeAt(x, z);
    if (place.en !== placeName) {
      placeName = place.en;
      placeEn.textContent = place.en;
      placeKo.textContent = place.ko;
    }
    let best = null;
    let bestD = Infinity;
    for (const sign of campus.signs) {
      const dist = Math.hypot(x - sign.x, z - sign.z);
      if (dist < sign.r && dist < bestD) {
        best = sign;
        bestD = dist;
      }
    }
    if (!best) {
      near.hidden = true;
      nearId = "";
      return;
    }
    if (nearId === best.id && !near.hidden) return;
    nearId = best.id;
    near.hidden = false;
    nearTitle.textContent = best.title;
    nearKo.textContent = best.ko;
    nearBody.textContent = `${best.body}\n${best.bodyKo}`;
  };

  const probeReport = campus.probes.map((probe) => {
    const actual = campus.blocked(probe.x, probe.z);
    return { ...probe, actual, ok: actual === probe.want };
  });

  let last = performance.now();
  let frames = 0;
  renderer.setAnimationLoop((time) => {
    const now = time || performance.now();
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    const session = renderer.xr.getSession();
    player.update(dt, session);
    if (!reduceMotion) campus.tick(now / 1000);
    if (!shot) {
      updateHud(player.state.x, player.state.z);
      const snack = nearestSnack(player.state.x, player.state.z);
      pickup.hidden = !snack;
      const board = nearestBoard(player.state.x, player.state.z);
      writer.hidden = !board;
      syncMeet(player.state.x, player.state.z);
      const person = nearestPerson(player.state.x, player.state.z);
      talk.hidden = !person;
      if (!person) {
        talk.dataset.who = "";
      } else if (talk.dataset.who !== person.name) {
        talk.dataset.who = person.name;
        promptHello(person);
      }
      const pressed = gamepadPickup(session);
      if (pressed && !pickupWasDown) {
        if (person) greet(person);
        else takeSnack(snack);
      }
      pickupWasDown = pressed;
    }
    renderer.render(campus.scene, camera);
    frames += 1;
    if (shot && frames >= 16) window.__shotReady = true;
  });

  window.__pose = () => ({ x: player.state.x, z: player.state.z, yaw: player.state.yaw });
  window.__place = (x, z, yaw, pitch) => player.place(x, z, yaw, pitch || 0);
  window.__campus = {
    blocked: campus.blocked,
    placeAt: campus.placeAt,
    probes: probeReport,
    signs: campus.signs.length,
    boards: campus.boards,
    people: campus.people,
    setTime: campus.setTime,
  };
  window.__capture = () => renderer.domElement.toDataURL("image/png");
  document.body.classList.add("ready");
  const failed = probeReport.filter((probe) => !probe.ok);
  if (failed.length) console.warn("Collision probes", failed);
  else console.info("Collision probes ok", probeReport.length);
}

boot().catch((error) => {
  console.error(error);
  const status = document.getElementById("status");
  if (status) status.textContent = `The campus could not open. ${error.message}`;
});
