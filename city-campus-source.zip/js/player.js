import * as THREE from "three";

const EYE = 1.62;
const LOOK_LIMIT = 1.15;

function clamp(v, a, b) {
  return Math.max(a, Math.min(b, v));
}

function stickAxes(gamepad) {
  if (!gamepad || !gamepad.axes) return null;
  const ax = gamepad.axes;
  let x = ax[0] || 0;
  let y = ax[1] || 0;
  if (ax.length > 3 && Math.hypot(ax[2], ax[3]) > Math.hypot(x, y)) {
    x = ax[2];
    y = ax[3];
  }
  if (Math.abs(x) < 0.18) x = 0;
  if (Math.abs(y) < 0.18) y = 0;
  return { x, y };
}

export function createPlayer({ camera, canvas, blocked, joystick, knob, onPress }) {
  const rig = new THREE.Group();
  rig.add(camera);
  camera.position.set(0, EYE, 0);
  camera.rotation.order = "YXZ";

  const keys = new Set();
  const pointers = new Map();
  const joy = { x: 0, y: 0, active: false };
  const state = {
    x: 0,
    z: 4.6,
    yaw: 0,
    pitch: 0,
    vx: 0,
    vz: 0,
    freeze: false,
  };

  function onKeyDown(e) {
    const tag = e.target && e.target.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA") return;
    const k = e.key.toLowerCase();
    if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(k)) {
      e.preventDefault();
    }
    keys.add(k);
  }
  function onKeyUp(e) {
    keys.delete(e.key.toLowerCase());
  }
  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("keyup", onKeyUp);
  window.addEventListener("blur", () => keys.clear());

  canvas.addEventListener("pointerdown", (e) => {
    if (state.freeze) return;
    if (e.pointerType === "mouse" && e.button === 0 && document.pointerLockElement !== canvas) {
      if (onPress && onPress(e)) return;
      canvas.requestPointerLock();
    }
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
  });
  canvas.addEventListener("pointermove", (e) => {
    const prev = pointers.get(e.pointerId);
    if (!prev || state.freeze) return;
    const dx = e.clientX - prev.x;
    const dy = e.clientY - prev.y;
    prev.x = e.clientX;
    prev.y = e.clientY;
    if (document.pointerLockElement === canvas) return;
    state.yaw -= dx * 0.0048;
    state.pitch += dy * 0.004;
    state.pitch = clamp(state.pitch, -LOOK_LIMIT, LOOK_LIMIT);
  });
  function endPointer(e) {
    pointers.delete(e.pointerId);
  }
  canvas.addEventListener("pointerup", endPointer);
  canvas.addEventListener("pointercancel", endPointer);
  document.addEventListener("mousemove", (e) => {
    if (document.pointerLockElement !== canvas || state.freeze) return;
    state.yaw -= e.movementX * 0.0022;
    state.pitch += e.movementY * 0.002;
    state.pitch = clamp(state.pitch, -LOOK_LIMIT, LOOK_LIMIT);
  });

  if (joystick && knob) {
    const moveKnob = (clientX, clientY) => {
      const rect = joystick.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      let dx = clientX - cx;
      let dy = clientY - cy;
      const max = rect.width * 0.34;
      const len = Math.hypot(dx, dy) || 1;
      const clamped = Math.min(len, max);
      dx = (dx / len) * clamped;
      dy = (dy / len) * clamped;
      knob.style.transform = `translate(${dx}px, ${dy}px)`;
      joy.x = dx / max;
      joy.y = dy / max;
    };
    joystick.addEventListener("pointerdown", (e) => {
      joy.active = true;
      joystick.setPointerCapture(e.pointerId);
      moveKnob(e.clientX, e.clientY);
      e.stopPropagation();
    });
    joystick.addEventListener("pointermove", (e) => {
      if (!joy.active) return;
      moveKnob(e.clientX, e.clientY);
    });
    const endJoy = () => {
      joy.active = false;
      joy.x = 0;
      joy.y = 0;
      knob.style.transform = "translate(0px, 0px)";
    };
    joystick.addEventListener("pointerup", endJoy);
    joystick.addEventListener("pointercancel", endJoy);
  }

  function readXR(session) {
    let left = null;
    let right = null;
    if (!session) return { moveX: 0, moveY: 0, turn: 0 };
    for (const source of session.inputSources) {
      const axes = stickAxes(source.gamepad);
      if (!axes) continue;
      if (source.handedness === "right") right = axes;
      else left = axes;
    }
    if (left && right) {
      return { moveX: left.x, moveY: left.y, turn: right.x };
    }
    const only = left || right;
    if (!only) return { moveX: 0, moveY: 0, turn: 0 };
    return { moveX: only.x, moveY: only.y, turn: right ? right.x : 0 };
  }

  function tryStep(dx, dz) {
    const dist = Math.hypot(dx, dz);
    const steps = Math.max(1, Math.ceil(dist / 0.12));
    let x = state.x;
    let z = state.z;
    const sx = dx / steps;
    const sz = dz / steps;
    for (let i = 0; i < steps; i += 1) {
      if (!blocked(x + sx, z)) x += sx;
      if (!blocked(x, z + sz)) z += sz;
    }
    state.x = x;
    state.z = z;
  }

  function update(dt, session) {
    if (state.freeze) return;
    const presenting = Boolean(session);
    let inputX = 0;
    let inputZ = 0;
    if (keys.has("a") || keys.has("arrowleft")) inputX -= 1;
    if (keys.has("d") || keys.has("arrowright")) inputX += 1;
    if (keys.has("w") || keys.has("arrowup")) inputZ -= 1;
    if (keys.has("s") || keys.has("arrowdown")) inputZ += 1;
    inputX += joy.x;
    inputZ += joy.y;

    const xr = readXR(session);
    inputX += xr.moveX;
    inputZ += xr.moveY;
    if (presenting && Math.abs(xr.turn) > 0) {
      state.yaw -= xr.turn * 1.55 * dt;
    }

    const len = Math.hypot(inputX, inputZ);
    if (len > 1) {
      inputX /= len;
      inputZ /= len;
    }

    const euler = new THREE.Euler().setFromQuaternion(
      camera.getWorldQuaternion(new THREE.Quaternion()),
      "YXZ",
    );
    const yaw = presenting ? euler.y : state.yaw;
    const sin = Math.sin(yaw);
    const cos = Math.cos(yaw);
    const fx = -sin;
    const fz = -cos;
    const rx = cos;
    const rz = -sin;
    const speed = keys.has("shift") ? 6.4 : 4.15;
    const wishX = (rx * inputX + fx * -inputZ) * speed;
    const wishZ = (rz * inputX + fz * -inputZ) * speed;
    state.vx = THREE.MathUtils.damp(state.vx, wishX, 12, dt);
    state.vz = THREE.MathUtils.damp(state.vz, wishZ, 12, dt);
    tryStep(state.vx * dt, state.vz * dt);

    rig.position.set(state.x, 0, state.z);
    rig.rotation.y = state.yaw;
    if (!presenting) {
      camera.position.set(0, EYE, 0);
      camera.rotation.set(state.pitch, 0, 0);
    }
    rig.updateMatrixWorld(true);
  }

  function place(x, z, yaw = 0, pitch = 0) {
    state.x = x;
    state.z = z;
    state.yaw = yaw;
    state.pitch = pitch;
    state.vx = 0;
    state.vz = 0;
    rig.position.set(x, 0, z);
    rig.rotation.y = yaw;
    camera.rotation.x = pitch;
    rig.updateMatrixWorld(true);
  }

  return { rig, state, update, place, eye: EYE };
}
