import * as THREE from "three";

const DISPLAY = "Fraunces, Palatino, serif";
const SANS = "Nunito, sans-serif";
const KR = '"Noto Sans KR", Nunito, sans-serif';

function canvas(w, h) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  return c;
}

function texture(c, anisotropy, repeat) {
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = anisotropy || 8;
  if (repeat) {
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(repeat[0], repeat[1]);
  }
  tex.needsUpdate = true;
  return tex;
}

function drawRose(g, x, y, scale) {
  g.save();
  g.translate(x, y);
  g.scale(scale, scale);
  g.fillStyle = "#E7B7C6";
  for (let i = 0; i < 6; i += 1) {
    const a = -Math.PI / 2 + (i * Math.PI) / 3;
    g.beginPath();
    g.arc(Math.cos(a) * 16, Math.sin(a) * 16, 14, 0, Math.PI * 2);
    g.fill();
  }
  g.fillStyle = "#F6DDE4";
  g.beginPath();
  g.arc(0, 0, 11, 0, Math.PI * 2);
  g.fill();
  g.fillStyle = "#6E1F2A";
  g.beginPath();
  g.arc(0, 0, 4.5, 0, Math.PI * 2);
  g.fill();
  g.restore();
}

function fit(g, text, weight, size, family, maxW) {
  let s = size;
  do {
    g.font = `${weight} ${s}px ${family}`;
    if (g.measureText(text).width <= maxW || s <= 18) break;
    s -= 2;
  } while (s > 18);
  return s;
}

export function heroTexture(anisotropy) {
  const c = canvas(2048, 768);
  const g = c.getContext("2d");
  const grd = g.createLinearGradient(0, 0, 2048, 0);
  grd.addColorStop(0, "#F8E4EA");
  grd.addColorStop(0.42, "#FFFBF5");
  grd.addColorStop(1, "#E5F0E6");
  g.fillStyle = grd;
  g.fillRect(0, 0, 2048, 768);
  g.fillStyle = "#E7B7C6";
  g.fillRect(0, 0, 2048, 16);
  g.fillRect(0, 752, 2048, 16);
  drawRose(g, 230, 384, 4.4);
  g.textAlign = "left";
  g.textBaseline = "middle";
  g.fillStyle = "#6E1F2A";
  g.font = `700 40px ${SANS}`;
  g.fillText("CITY CAMPUS", 470, 150);
  g.fillStyle = "#2E2420";
  fit(g, "Rose Morning", 700, 124, DISPLAY, 1500);
  g.fillText("Rose Morning", 470, 280);
  g.fillStyle = "#7A6A5E";
  g.font = `600 68px ${KR}`;
  g.fillText("로즈 모닝", 470, 390);
  g.fillStyle = "#2E2420";
  g.font = `600 46px ${DISPLAY}`;
  g.fillText("Bright minds. Beautiful mornings.", 470, 500);
  g.fillStyle = "#7A6A5E";
  g.font = `400 40px ${KR}`;
  g.fillText("밝은 마음, 아름다운 아침.", 470, 570);
  g.fillStyle = "#6E1F2A";
  g.font = `700 32px ${SANS}`;
  g.fillText("Group English   ·   AI study   ·   offices to rent", 470, 660);
  return texture(c, anisotropy);
}

export function headerTexture(title, ko, anisotropy) {
  const c = canvas(1536, 420);
  const g = c.getContext("2d");
  g.fillStyle = "#FFFBF5";
  g.fillRect(0, 0, 1536, 420);
  g.fillStyle = "#E7B7C6";
  g.fillRect(0, 0, 1536, 18);
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillStyle = "#2E2420";
  fit(g, title, 700, 120, DISPLAY, 1400);
  g.fillText(title, 768, 170);
  g.fillStyle = "#7A6A5E";
  fit(g, ko, 600, 72, KR, 1400);
  g.fillText(ko, 768, 290);
  return texture(c, anisotropy);
}

export function posterTexture(opts, anisotropy) {
  const w = opts.w || 1024;
  const h = opts.h || 1280;
  const c = canvas(w, h);
  const g = c.getContext("2d");
  g.fillStyle = opts.bg || "#FFFBF5";
  g.fillRect(0, 0, w, h);
  g.fillStyle = opts.accent || "#A8823C";
  g.fillRect(0, 0, w, 22);
  g.textAlign = "center";
  g.textBaseline = "middle";
  let y = 110;
  if (opts.kicker) {
    g.fillStyle = opts.accent || "#6E1F2A";
    g.font = `700 36px ${SANS}`;
    g.fillText(opts.kicker, w / 2, y);
    y += 90;
  }
  g.fillStyle = "#2E2420";
  fit(g, opts.title, 700, opts.titleSize || 78, DISPLAY, w - 100);
  g.fillText(opts.title, w / 2, y);
  y += 90;
  g.fillStyle = "#7A6A5E";
  fit(g, opts.ko, 600, opts.koSize || 58, KR, w - 100);
  g.fillText(opts.ko, w / 2, y);
  y += 70;
  g.fillStyle = opts.accent || "#A8823C";
  g.fillRect(w / 2 - 70, y, 140, 6);
  y += 70;
  const maxW = w - 120;
  for (const block of opts.blocks || []) {
    g.fillStyle = "#2E2420";
    for (const line of block.en) {
      fit(g, line, 600, 40, SANS, maxW);
      g.fillText(line, w / 2, y);
      y += 52;
    }
    y += 8;
    g.fillStyle = "#7A6A5E";
    for (const line of block.ko) {
      fit(g, line, 400, 36, KR, maxW);
      g.fillText(line, w / 2, y);
      y += 48;
    }
    y += 36;
  }
  return texture(c, anisotropy);
}

export function whiteboardTexture(anisotropy) {
  const c = canvas(2048, 1152);
  const g = c.getContext("2d");
  g.fillStyle = "#F4FBFC";
  g.fillRect(0, 0, 2048, 1152);
  g.strokeStyle = "#D5E3EA";
  g.lineWidth = 4;
  for (let y = 180; y < 1100; y += 120) {
    g.beginPath();
    g.moveTo(120, y);
    g.lineTo(1920, y);
    g.stroke();
  }
  drawRose(g, 1840, 160, 2.2);
  const rows = [
    ["Good morning.", 700, 86, DISPLAY, "#2F4354", 150],
    ["좋은 아침이에요.", 600, 58, KR, "#7A6A5E", 250],
    ["I'm ____.", 700, 78, DISPLAY, "#2F4354", 420],
    ["저는 ____ 입니다.", 600, 54, KR, "#7A6A5E", 510],
    ["Nice to meet you.", 700, 72, DISPLAY, "#2F4354", 680],
    ["만나서 반가워요.", 600, 54, KR, "#7A6A5E", 770],
    ["Today: small groups.", 600, 48, SANS, "#6E1F2A", 940],
    ["오늘: 모둠 활동.", 600, 44, KR, "#6E1F2A", 1020],
  ];
  g.textAlign = "left";
  g.textBaseline = "middle";
  for (const [text, weight, size, family, color, y] of rows) {
    g.fillStyle = color;
    g.font = `${weight} ${size}px ${family}`;
    g.fillText(text, 160, y);
  }
  return texture(c, anisotropy);
}

export function aiWallTexture(anisotropy) {
  const c = canvas(2048, 1152);
  const g = c.getContext("2d");
  g.fillStyle = "#2A3B4E";
  g.fillRect(0, 0, 2048, 1152);
  const nodes = [
    [980, 360],
    [1280, 240],
    [1500, 460],
    [1240, 680],
    [1680, 300],
    [1700, 700],
    [1040, 860],
  ];
  g.strokeStyle = "rgba(232, 214, 196, 0.45)";
  g.lineWidth = 6;
  const links = [
    [0, 1],
    [0, 2],
    [0, 3],
    [1, 4],
    [2, 5],
    [3, 6],
    [2, 3],
  ];
  for (const [a, b] of links) {
    g.beginPath();
    g.moveTo(nodes[a][0], nodes[a][1]);
    g.lineTo(nodes[b][0], nodes[b][1]);
    g.stroke();
  }
  const colors = ["#F2C1CB", "#F3E2A8", "#B7D3C6", "#D5E4F5", "#F2C1CB", "#F3E2A8", "#B7D3C6"];
  nodes.forEach(([x, y], i) => {
    g.fillStyle = colors[i];
    g.beginPath();
    g.arc(x, y, i === 0 ? 34 : 22, 0, Math.PI * 2);
    g.fill();
  });
  g.textAlign = "left";
  g.textBaseline = "middle";
  g.fillStyle = "#F7EFE8";
  g.font = `700 78px ${DISPLAY}`;
  g.fillText("AI study", 120, 250);
  g.font = `600 52px ${KR}`;
  g.fillStyle = "#E7C9D2";
  g.fillText("AI 공부", 120, 340);
  g.font = `700 40px ${SANS}`;
  g.fillStyle = "#F7EFE8";
  g.fillText("Ask together.", 120, 470);
  g.fillText("Check together.", 120, 530);
  g.font = `400 36px ${KR}`;
  g.fillStyle = "#D5E0EA";
  g.fillText("함께 묻고, 함께 확인해요.", 120, 610);
  const cards = [
    ["What do we know?", "무엇을 알고 있나요?"],
    ["Who is this for?", "누구를 위한 건가요?"],
    ["How would we check it?", "어떻게 확인할까요?"],
  ];
  cards.forEach((card, i) => {
    const y = 720 + i * 120;
    g.fillStyle = "rgba(255, 248, 243, 0.1)";
    g.fillRect(120, y, 760, 100);
    g.fillStyle = "#F7EFE8";
    g.font = `700 36px ${SANS}`;
    g.fillText(card[0], 150, y + 38);
    g.fillStyle = "#E7C9D2";
    g.font = `400 30px ${KR}`;
    g.fillText(card[1], 150, y + 74);
  });
  return texture(c, anisotropy);
}

export function promptTexture(en, ko, anisotropy) {
  const c = canvas(1024, 768);
  const g = c.getContext("2d");
  g.fillStyle = "#FFFBF5";
  g.fillRect(0, 0, 1024, 768);
  g.fillStyle = "#E7B7C6";
  g.fillRect(0, 0, 18, 768);
  g.textAlign = "left";
  g.textBaseline = "middle";
  g.fillStyle = "#6E1F2A";
  g.font = `700 32px ${SANS}`;
  g.fillText("TRY THIS", 80, 180);
  g.fillStyle = "#2E2420";
  fit(g, en, 700, 64, DISPLAY, 880);
  g.fillText(en, 80, 340);
  g.fillStyle = "#7A6A5E";
  fit(g, ko, 600, 44, KR, 880);
  g.fillText(ko, 80, 450);
  return texture(c, anisotropy);
}

export function mapTexture(anisotropy) {
  const c = canvas(1024, 1280);
  const g = c.getContext("2d");
  g.fillStyle = "#FFFBF5";
  g.fillRect(0, 0, 1024, 1280);
  g.fillStyle = "#E7B7C6";
  g.fillRect(0, 0, 1024, 18);
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillStyle = "#2E2420";
  g.font = `700 64px ${DISPLAY}`;
  g.fillText("Campus map", 512, 90);
  g.fillStyle = "#7A6A5E";
  g.font = `600 36px ${KR}`;
  g.fillText("캠퍼스 지도", 512, 150);
  g.font = `700 28px ${SANS}`;
  g.fillStyle = "#6E1F2A";
  g.fillText("N", 512, 210);

  const rooms = [
    [150, 250, 724, 200, "#FFBE7A", "Quiet garden", "고요한 정원"],
    [150, 470, 220, 250, "#D4C4FF", "AI study", "AI 공부"],
    [390, 470, 244, 250, "#FFD27A", "Lobby", "로비"],
    [654, 470, 220, 250, "#FFB07A", "English", "영어 교실"],
    [150, 740, 220, 280, "#B9D4FF", "AI office", "AI 사무실"],
    [390, 740, 244, 280, "#FFAA78", "Sea terrace", "바다 테라스"],
    [654, 740, 220, 134, "#FFB3C7", "Club room", "동아리실"],
    [654, 886, 220, 134, "#FFAA90", "Sea club", "바다 동아리"],
  ];
  for (const [x, y, w, h, fill, en, ko] of rooms) {
    g.fillStyle = fill;
    g.fillRect(x, y, w, h);
    g.fillStyle = "#2E2420";
    g.font = `700 28px ${SANS}`;
    g.fillText(en, x + w / 2, y + h / 2 - 28);
    g.fillStyle = "#7A6A5E";
    g.font = `400 24px ${KR}`;
    g.fillText(ko, x + w / 2, y + h / 2 + 6);
  }
  g.fillStyle = "#6E1F2A";
  g.beginPath();
  g.arc(512, 650, 11, 0, Math.PI * 2);
  g.fill();
  g.font = `700 22px ${SANS}`;
  g.fillText("You are here", 512, 682);
  g.font = `400 20px ${KR}`;
  g.fillStyle = "#7A6A5E";
  g.fillText("여기", 512, 706);
  return texture(c, anisotropy);
}

export function medallionTexture(anisotropy) {
  const c = canvas(1024, 1024);
  const g = c.getContext("2d");
  g.fillStyle = "#F4E1E6";
  g.fillRect(0, 0, 1024, 1024);
  g.fillStyle = "#F8E7EC";
  g.beginPath();
  g.arc(512, 512, 500, 0, Math.PI * 2);
  g.fill();
  g.strokeStyle = "#E7B7C6";
  g.lineWidth = 22;
  g.stroke();
  drawRose(g, 512, 390, 3.1);
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillStyle = "#2E2420";
  g.font = `700 120px ${DISPLAY}`;
  g.fillText("RM", 512, 620);
  g.fillStyle = "#7A6A5E";
  g.font = `600 42px ${KR}`;
  g.fillText("로즈 모닝", 512, 730);
  return texture(c, anisotropy);
}

export function plankTexture(anisotropy) {
  const c = canvas(512, 512);
  const g = c.getContext("2d");
  const boards = [78, 92, 70, 104, 84, 84];
  let y = 0;
  boards.forEach((h, i) => {
    const tone = 168 + ((i * 17) % 28);
    g.fillStyle = `rgb(${tone + 28}, ${tone - 4}, ${tone - 38})`;
    g.fillRect(0, y, 512, h - 3);
    g.strokeStyle = "rgba(90, 58, 32, 0.18)";
    g.lineWidth = 1;
    for (let x = 12 + (i % 3) * 8; x < 500; x += 18) {
      g.beginPath();
      g.moveTo(x, y + 4);
      g.lineTo(x + ((i % 2) ? 6 : -4), y + h - 8);
      g.stroke();
    }
    if (i % 2 === 0) {
      g.fillStyle = "rgba(92, 60, 34, 0.16)";
      g.beginPath();
      g.ellipse(80 + (i * 47) % 340, y + h * 0.45, 7, 4, 0.4, 0, Math.PI * 2);
      g.fill();
    }
    g.fillStyle = "rgba(70, 46, 28, 0.35)";
    g.fillRect(0, y + h - 3, 512, 3);
    y += h;
  });
  return texture(c, anisotropy, [3, 3]);
}

export function gridTexture(anisotropy) {
  const c = canvas(512, 512);
  const g = c.getContext("2d");
  g.fillStyle = "#F3E6D4";
  g.fillRect(0, 0, 512, 512);
  g.strokeStyle = "rgba(196, 146, 106, 0.45)";
  g.lineWidth = 4;
  for (let i = 0; i <= 512; i += 64) {
    g.beginPath();
    g.moveTo(i, 0);
    g.lineTo(i, 512);
    g.stroke();
    g.beginPath();
    g.moveTo(0, i);
    g.lineTo(512, i);
    g.stroke();
  }
  return texture(c, anisotropy, [5, 4]);
}
